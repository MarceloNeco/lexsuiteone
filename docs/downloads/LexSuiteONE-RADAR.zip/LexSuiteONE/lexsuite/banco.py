"""Memória do robô (SQLite, um arquivo só: lexsuite.db).

Serve para: não avisar duas vezes o mesmo processo, guardar a situação de cada
ação (novo, visto, em análise, em contato, virou cliente, descartado, arquivado),
os contatos, o registro de quem fez o quê, as estatísticas diárias e não consultar
o mesmo CNPJ toda hora.
"""

import datetime as dt
import json
import os
import re
import sqlite3

# 0.7.13: situações do processo para o escritório (decisão do dono, 09/Nov). A chave fica no banco; o texto, na tela.
SITUACOES = ("novo", "visto", "em_analise", "em_contato", "virou_cliente", "descartado", "arquivado")
_SITUACAO_ANTIGA = {"novo": "novo", "nova": "novo", "visto": "visto", "vista": "visto", "lido": "visto",
                    "em analise": "em_analise", "em análise": "em_analise", "analise": "em_analise", "em_analise": "em_analise",
                    "abordado": "em_contato", "em contato": "em_contato", "contato": "em_contato", "em_contato": "em_contato",
                    "cliente": "virou_cliente", "virou cliente": "virou_cliente", "virou_cliente": "virou_cliente",
                    "contratado": "virou_cliente", "descartado": "descartado", "arquivado": "arquivado", "tratado": "arquivado"}
# Faixas de valor das Estatísticas e do filtro (limite superior aberto); "sem" = o Diário não trouxe o valor.
FAIXAS = ((10000, "ate10k"), (50000, "10k-50k"), (100000, "50k-100k"), (300000, "100k-300k"), (500000, "300k-500k"),
          (1000000, "500k-1mi"), (float("inf"), "1mi+"))
# O que fica de cada ação depois que o dado completo é limpo (sem o trecho do Diário, onde aparece o reclamante).
# 0.7.18: frases de intimação comum que a regra de "ação nova" até a 0.7.15 aceitava (ver classificar._INICIO)
_INTIMACAO_COMUM = re.compile(r"fica\s+.{0,40}notificad|designad[ao]\s+audiencia|citacao|intimad|intimacao", re.I)

_RESUMO = ("processo", "tribunal", "vara", "classe", "rito", "data_publicacao", "ajuizada_em", "empresas", "cnpjs",
           "valor_causa", "fonte", "link", "visto_em", "rodada", "cnpj_a_conferir", "manual", "sinal",
           "manual_historico", "fonte_leitura", "caderno_pendente")  # 0.7.48 (revisão): o histórico do que foi digitado não sai no resumo
_RESUMO_RECEITA = ("cnpj", "razao_social", "nome_fantasia", "porte", "capital_social", "cnae", "atividade", "municipio",
                   "uf", "telefone", "telefone2", "email", "logradouro", "numero", "complemento", "bairro", "cep",
                   "situacao", "inicio_atividade", "simples", "socios", "consultado_em")


def situacao_valida(s):
    return _SITUACAO_ANTIGA.get(str(s or "").strip().lower(), "")


def faixa_valor(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "sem"
    if v <= 0:
        return "sem"
    for teto, nome in FAIXAS:
        if v < teto:
            return nome
    return "1mi+"


def agora_utc_e_fuso():
    """(quando em UTC, fuso do computador como '-03:00') para o registro de quem fez o quê."""
    agora = dt.datetime.now(dt.timezone.utc)
    off = dt.datetime.now().astimezone().utcoffset() or dt.timedelta(0)
    m = int(off.total_seconds() // 60)
    return agora.isoformat(timespec="seconds"), f"{'+' if m >= 0 else '-'}{abs(m) // 60:02d}:{abs(m) % 60:02d}"


def _tam(caminho):
    try:
        return os.path.getsize(caminho)
    except OSError:
        return 0


class Banco:
    def __init__(self, caminho="lexsuite.db"):
        # 0.7.34 (teste do dono): a busca de estatísticas e a tela gravam no mesmo banco; espera até 30 s pela vez em vez de
        # cair com "database is locked" (o padrão do sqlite3 é 5 s)
        self.con = sqlite3.connect(caminho, timeout=30)
        self.con.executescript("""
            CREATE TABLE IF NOT EXISTS leads (
                processo TEXT PRIMARY KEY, primeira_vez TEXT, tribunal TEXT, vara TEXT,
                dados TEXT, status TEXT DEFAULT 'Novo');
            CREATE TABLE IF NOT EXISTS cnpj (cnpj TEXT PRIMARY KEY, quando TEXT, dados TEXT);
            CREATE TABLE IF NOT EXISTS execucoes (quando TEXT, tipo TEXT, resumo TEXT);
            CREATE TABLE IF NOT EXISTS publicacoes (
                chave TEXT PRIMARY KEY, visto_em TEXT, data TEXT, processo TEXT,
                dados TEXT, status TEXT DEFAULT 'Nova');
            CREATE TABLE IF NOT EXISTS cadernos (tribunal TEXT, data TEXT, versao TEXT, quando TEXT,
                PRIMARY KEY (tribunal, data));
            CREATE TABLE IF NOT EXISTS rodadas (id TEXT PRIMARY KEY, quando TEXT, modo TEXT,
                conferidas INTEGER, novas_processos INTEGER, novas_acoes INTEGER, detalhes TEXT);
            CREATE TABLE IF NOT EXISTS acoes (quando_utc TEXT, fuso TEXT, perfil TEXT, acao TEXT, alvo TEXT,
                antes TEXT, depois TEXT, quantos INTEGER);
            CREATE TABLE IF NOT EXISTS contatos (id INTEGER PRIMARY KEY AUTOINCREMENT, processo TEXT, empresa TEXT,
                canal TEXT, valor TEXT, de_pessoa INTEGER DEFAULT 0, fonte TEXT, data TEXT, confianca TEXT, origem TEXT,
                observacao TEXT, arquivo TEXT, validacao TEXT DEFAULT '', validado_por TEXT DEFAULT '',
                validado_em TEXT DEFAULT '', criado_em TEXT, UNIQUE (processo, canal, valor));
            CREATE TABLE IF NOT EXISTS contatos_historico (quando_utc TEXT, fuso TEXT, perfil TEXT, arquivo TEXT,
                aceitas INTEGER, recusadas INTEGER, detalhe TEXT);
            CREATE TABLE IF NOT EXISTS estatisticas_diarias (data TEXT, tribunal TEXT, vara TEXT, frente TEXT,
                porte TEXT, faixa_valor TEXT, novas INTEGER DEFAULT 0, encerradas INTEGER DEFAULT 0, atualizado_em TEXT,
                PRIMARY KEY (data, tribunal, vara, frente, porte, faixa_valor));
            CREATE TABLE IF NOT EXISTS historico (tribunal TEXT, data TEXT, situacao TEXT, novas INTEGER DEFAULT 0,
                quando TEXT, PRIMARY KEY (tribunal, data));
            CREATE TABLE IF NOT EXISTS historico_processos (processo TEXT PRIMARY KEY);
            CREATE TABLE IF NOT EXISTS cadernos_pendentes (tribunal TEXT, data TEXT, quando TEXT, PRIMARY KEY (tribunal, data));
            CREATE TABLE IF NOT EXISTS area_logada (processo TEXT, dado TEXT, pedido_em TEXT DEFAULT '', pedido_id TEXT DEFAULT '',
                respondido_em TEXT DEFAULT '', resultado TEXT DEFAULT '', fonte TEXT DEFAULT '', PRIMARY KEY (processo, dado));
            CREATE TABLE IF NOT EXISTS area_pedidos (id TEXT PRIMARY KEY, criado_em TEXT, processos INTEGER, lotes INTEGER,
                ferramenta TEXT DEFAULT '', estado TEXT DEFAULT 'pendente', arquivo TEXT DEFAULT '', recebidos TEXT DEFAULT '[]',
                resumo TEXT DEFAULT '{}');
            CREATE TABLE IF NOT EXISTS processos_apagados (processo TEXT PRIMARY KEY, apagado_em TEXT, diario_data TEXT);
            CREATE TABLE IF NOT EXISTS varas (tribunal TEXT, id_orgao TEXT, nome TEXT, visto_em TEXT, PRIMARY KEY (tribunal, id_orgao));
            CREATE TABLE IF NOT EXISTS consultas_dia (tribunal TEXT, data TEXT, quando TEXT, publicacoes INTEGER DEFAULT 0,
                pedidos INTEGER DEFAULT 0, parcial INTEGER DEFAULT 0, processos TEXT DEFAULT '[]', conferida_em TEXT DEFAULT '',
                a_mais INTEGER DEFAULT 0, PRIMARY KEY (tribunal, data));
        """)
        colunas = {r[1] for r in self.con.execute("PRAGMA table_info(leads)")}
        for nome, tipo in (("frente", "TEXT DEFAULT ''"), ("motivo", "TEXT DEFAULT ''"), ("status_em", "TEXT DEFAULT ''"),
                           ("bruto_limpo", "INTEGER DEFAULT 0"), ("data", "TEXT DEFAULT ''"), ("porte", "TEXT DEFAULT ''"),
                           ("faixa_valor", "TEXT DEFAULT ''"), ("fora_criterio", "INTEGER DEFAULT 0")):
            if nome not in colunas:
                self.con.execute(f"ALTER TABLE leads ADD COLUMN {nome} {tipo}")  # nosec B608 - nomes fixos acima
        # Situações antigas (Novo, Visto, Em contato, Descartado) passam para as chaves novas, uma vez (versão do esquema).
        if (self.con.execute("PRAGMA user_version").fetchone() or [0])[0] < 714:
            for antigo, novo in _SITUACAO_ANTIGA.items():
                self.con.execute("UPDATE leads SET status = ? WHERE lower(status) = ? AND status <> ?", (novo, antigo, novo))
            self.con.execute("UPDATE leads SET status = 'novo' WHERE status IS NULL OR status = ''")
            self._preencher_resumo()
            self.con.execute("PRAGMA user_version = 714")
            self.con.commit()
        if (self.con.execute("PRAGMA user_version").fetchone() or [0])[0] < 718:
            if caminho and os.path.exists(caminho) and self.con.execute("SELECT count(*) FROM leads").fetchone()[0]:
                self._copia_antes(caminho, "0.7.18")
            self._reclassificar_0718()
            self.con.execute("PRAGMA user_version = 719")
            self.con.commit()
        elif (self.con.execute("PRAGMA user_version").fetchone()[0] or 0) == 718:
            # 0.7.19: quem rodou a 0.7.18 antes da correção tinha turma trabalhada escondida; volta para a lista
            self.con.execute("UPDATE leads SET fora_criterio = 0 WHERE fora_criterio = 1 AND (coalesce(status, 'novo') <> 'novo' "
                             "OR dados LIKE '%\"manual\"%' OR processo IN (SELECT DISTINCT processo FROM contatos))")
            self.con.execute("PRAGMA user_version = 719")
            self.con.commit()
        self.caminho = caminho

    def _copia_antes(self, caminho, versao):
        """Cópia do banco antes de uma mudança única, ao lado dele, com data no nome (lexsuite.db.antes-0.7.18-AAAA-MM-DD).
        Grava num arquivo temporário e só então dá o nome final: cópia pela metade (disco cheio) nunca passa por boa."""
        import shutil
        destino = f"{caminho}.antes-{versao}-{dt.date.today().isoformat()}"
        tmp = destino + ".tmp"
        try:
            # revisão da 0.7.19: cópia pela metade (.tmp de uma queda de energia) não conta como pronta
            if any(n.startswith(os.path.basename(caminho) + f".antes-{versao}") and not n.endswith(".tmp")
                   for n in os.listdir(os.path.dirname(caminho) or ".")):
                return
            self.con.commit()
            shutil.copyfile(caminho, tmp)
            os.replace(tmp, destino)
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass

    def _reclassificar_0718(self):
        """0.7.18, uma vez: o que foi guardado pela regra antiga e não é ação nova sai da Lista, do Arquivo, da planilha e
        das estatísticas (fica no banco, marcado `fora_criterio`). Conservador: fica tudo o que tem sinal de distribuição
        ou de começo de ação, o que já foi trabalhado e o que tem dado completado à mão ou contato."""
        from . import classificar as cl
        com_contato = {r[0] for r in self.con.execute("SELECT DISTINCT processo FROM contatos")}
        marcar = []
        for proc, dados, status, vara in self.con.execute("SELECT processo, dados, status, vara FROM leads"):
            try:
                d = json.loads(dados or "{}")
            except ValueError:
                continue
            if (status or "novo") != "novo" or d.get("manual") or proc in com_contato:
                continue  # trabalhado, completado ou com contato: fica sempre (revisão da 0.7.18)
            if cl.segundo_grau(vara or d.get("vara")):
                marcar.append((proc,))
                continue
            if "texto_curto" not in d or d.get("sinal"):
                continue  # trabalhado, completado, com contato, sem texto para conferir, ou já guardado pela regra nova
            texto = cl.sem_acento(" ".join(str(d.get(k) or "") for k in ("tipo", "texto_curto"))).lower()
            if "distribu" in texto or cl.parece_inicio(d.get("texto_curto") or ""):
                continue
            # Só sai o que mostra sinal de intimação comum (a regra antiga aceitava); sem esse sinal, fica (na dúvida, fica)
            if not _INTIMACAO_COMUM.search(cl.sem_acento(d.get("texto_curto") or "")):
                continue
            marcar.append((proc,))
        self.con.executemany("UPDATE leads SET fora_criterio = 1 WHERE processo = ?", marcar)
        if marcar:
            self.con.execute("DELETE FROM estatisticas_diarias")  # refeitas na próxima atualização, já sem os marcados
            self.registrar_acao("automático", "reclassificar:0.7.18", "regra de ação nova da 0.7.16 e 2º grau", "", "", len(marcar))

    def _preencher_resumo(self):
        """Ações guardadas antes da 0.7.13: preenche data, frente, porte e faixa de valor (uma vez)."""
        from . import frentes
        faltam = self.con.execute("SELECT processo, dados, primeira_vez FROM leads WHERE data = '' OR data IS NULL").fetchall()
        for proc, dados, quando in faltam:
            try:
                d = json.loads(dados or "{}")
            except ValueError:
                d = {}
            emp = d.get("empresa_receita") or {}
            self.con.execute("UPDATE leads SET data = ?, frente = ?, porte = ?, faixa_valor = ? WHERE processo = ?",
                             ((d.get("data_publicacao") or quando or "")[:10], frentes.frente(d), emp.get("porte") or "",
                              faixa_valor(d.get("valor_causa")), proc))

    def processos_vistos(self):
        """Os processos já conhecidos; 0.7.48: os apagados pela limpeza também, para não voltarem como novos."""
        return {r[0] for r in self.con.execute("SELECT processo FROM leads UNION SELECT processo FROM processos_apagados")}

    def guardar_lead(self, lead, primeira_vez=None):
        from . import frentes
        quando = primeira_vez or dt.date.today().isoformat()
        emp = lead.get("empresa_receita") or {}
        self.con.execute(
            "INSERT OR IGNORE INTO leads (processo, primeira_vez, tribunal, vara, dados, status, frente, data, porte, faixa_valor) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (lead["processo"], quando, lead.get("tribunal"), lead.get("vara"), json.dumps(lead, ensure_ascii=False), "novo",
             frentes.frente(lead), (lead.get("data_publicacao") or quando)[:10], emp.get("porte") or "",
             faixa_valor(lead.get("valor_causa"))))
        self.con.commit()

    # --- Situação do processo (0.7.13) ---

    def mudar_situacao(self, processos, situacao, perfil="", motivo=""):
        """Muda a situação de um ou muitos processos. Devolve {quantos, antes: {processo: situação}} (para desfazer).
        Registra quem, quando (UTC e fuso), o quê e quantos na tabela `acoes`."""
        situacao = situacao_valida(situacao)
        if not situacao:
            raise ValueError("Situação desconhecida.")
        processos = [str(p) for p in (processos or []) if p][:20000]
        antes = {}
        for i in range(0, len(processos), 500):
            parte = processos[i:i + 500]
            marcas = ",".join("?" * len(parte))
            for proc, st in self.con.execute(f"SELECT processo, status FROM leads WHERE processo IN ({marcas})", parte):  # nosec B608
                antes[proc] = st or "novo"
        quando, fuso = agora_utc_e_fuso()
        self.con.executemany("UPDATE leads SET status = ?, motivo = ?, status_em = ? WHERE processo = ?",
                             [(situacao, (motivo or "")[:80] if situacao in ("descartado", "arquivado") else "", quando, p) for p in antes])
        self.registrar_acao(perfil, "situacao", ",".join(list(antes)[:50]), json.dumps(_contar(antes.values())), situacao, len(antes))
        self.con.commit()
        return {"quantos": len(antes), "antes": antes}

    def desfazer_situacao(self, antes, perfil=""):
        """Volta cada processo para a situação que tinha (o 'antes' devolvido por mudar_situacao)."""
        quando, fuso = agora_utc_e_fuso()
        pares = [(situacao_valida(st) or "novo", quando, str(p)) for p, st in (antes or {}).items()][:20000]
        self.con.executemany("UPDATE leads SET status = ?, status_em = ?, motivo = CASE WHEN ? IN ('descartado','arquivado') THEN motivo ELSE '' END "
                             "WHERE processo = ?", [(st, q, st, p) for st, q, p in pares])
        self.registrar_acao(perfil, "desfazer", "", "", json.dumps(_contar(st for st, _, _ in pares)), len(pares))
        self.con.commit()
        return len(pares)

    def registrar_acao(self, perfil, acao, alvo, antes, depois, quantos):
        quando, fuso = agora_utc_e_fuso()
        self.con.execute("INSERT INTO acoes VALUES (?,?,?,?,?,?,?,?)",
                         (quando, fuso, (perfil or "")[:120], acao, (alvo or "")[:2000], antes or "", depois or "", int(quantos or 0)))

    CAMPOS_MANUAIS = ("valor_causa", "data_ajuizamento", "uf")

    def completar(self, processo, campo, valor, fonte="digitado", data="", perfil=""):
        """0.7.16: guarda no programa um dado que o Diário não traz (valor da causa digitado no cartão ou vindo da área
        logada; data de ajuizamento), com fonte e data. Valor vazio apaga. Devolve True se o processo existe."""
        if campo not in self.CAMPOS_MANUAIS:
            raise ValueError("campo inválido")
        linha = self.con.execute("SELECT dados FROM leads WHERE processo = ?", (processo,)).fetchone()
        if not linha:
            return False
        dados = json.loads(linha[0])
        manual = dados.setdefault("manual", {})
        antes = str((manual.get(campo) or {}).get("valor") or "")
        if valor in (None, ""):
            manual.pop(campo, None)
        else:
            manual[campo] = {"valor": valor, "fonte": str(fonte or "digitado")[:80], "data": str(data or dt.date.today().isoformat())[:10]}
        if campo == "valor_causa":
            self.con.execute("UPDATE leads SET dados = ?, faixa_valor = ? WHERE processo = ?",
                             (json.dumps(dados, ensure_ascii=False), faixa_valor(valor if valor not in (None, "") else dados.get("valor_causa")), processo))
        else:
            self.con.execute("UPDATE leads SET dados = ? WHERE processo = ?", (json.dumps(dados, ensure_ascii=False), processo))
        self.registrar_acao(perfil, "completar:" + campo, processo, antes, str(valor or ""), 1)
        self.con.commit()
        return True

    # --- 0.7.46 (Área logada v2): fonte mais forte, memória por processo e dado, pedido pendente ---

    FORCA_FONTE = (("pje dados do processo", 6), ("pje peticao inicial", 5), ("pje citacao", 4), ("diario", 3), ("receita", 2))

    @classmethod
    def forca(cls, fonte):
        """Quanto vale uma fonte: cadastro da parte no PJe > petição > citação > Diário > Receita > digitado/outro."""
        from . import classificar as cl
        f = cl.sem_acento(str(fonte or "")).lower()
        return next((v for k, v in cls.FORCA_FONTE if f.startswith(k)), 1)

    def completar_fonte(self, processo, campo, valor, fonte, data="", perfil=""):
        """Como completar(), mas NUNCA apaga e só troca o que existe por fonte mais forte (ou igual e mais nova); o anterior vai
        para o histórico da ficha (dados.manual_historico). Devolve (situação, antes, depois) com situação "acrescentado",
        "alterado", "igual", "mantido" (fonte mais fraca: fica o que estava) ou "" (processo não existe)."""
        if campo not in self.CAMPOS_MANUAIS or valor in (None, ""):
            return "", "", ""
        linha = self.con.execute("SELECT dados FROM leads WHERE processo = ?", (processo,)).fetchone()
        if not linha:
            return "", "", ""
        dados = json.loads(linha[0])
        atual = (dados.get("manual") or {}).get(campo) or {}
        if not atual and campo == "valor_causa" and dados.get("valor_causa"):
            atual = {"valor": dados.get("valor_causa"), "fonte": "Diário", "data": ""}
        def mesmo(a, b):
            try:
                return abs(float(a) - float(b)) < 0.005
            except (TypeError, ValueError):
                return str(a or "").strip().upper() == str(b or "").strip().upper()
        if atual and mesmo(atual.get("valor"), valor):
            return "igual", str(atual.get("valor")), str(valor)
        data = str(data or dt.date.today().isoformat())[:10]
        if atual:
            fa, fn = self.forca(atual.get("fonte")), self.forca(fonte)
            if fn < fa or (fn == fa and data < str(atual.get("data") or "")):
                return "mantido", str(atual.get("valor")), str(valor)
            hist = dados.setdefault("manual_historico", [])
            hist.append(dict(atual, campo=campo, trocado_em=dt.datetime.now().isoformat(timespec="seconds"), por=str(fonte)[:80]))
            del hist[:-50]
            self.con.execute("UPDATE leads SET dados = ? WHERE processo = ?", (json.dumps(dados, ensure_ascii=False), processo))
        self.completar(processo, campo, valor, fonte, data, perfil)
        return ("alterado" if atual else "acrescentado"), str(atual.get("valor") or "") if atual else "", str(valor)

    def area_registrar_pedido(self, ident, faltas, lotes, arquivo, ferramenta=""):
        """Grava o pedido (pendente) e marca "pedido em" em cada processo e dado. Um pedido pendente anterior vira "substituído"."""
        agora = dt.datetime.now().isoformat(timespec="seconds")
        for (velho,) in self.con.execute("SELECT id FROM area_pedidos WHERE estado = 'pendente'").fetchall():
            # revisão: os processos do pedido substituído que não tiveram resposta voltam a "ainda não pedido"
            self.con.execute("UPDATE area_logada SET pedido_em = '', pedido_id = '' WHERE pedido_id = ? AND respondido_em = ''", (velho,))
        self.con.execute("DELETE FROM area_logada WHERE pedido_em = '' AND respondido_em = ''")
        self.con.execute("UPDATE area_pedidos SET estado = 'substituido' WHERE estado = 'pendente'")
        self.con.execute("INSERT OR REPLACE INTO area_pedidos (id, criado_em, processos, lotes, ferramenta, estado, arquivo) VALUES (?,?,?,?,?,?,?)",
                         (ident, agora, len(faltas), int(lotes), str(ferramenta)[:40], "pendente", str(arquivo)[:300]))
        for proc, dados in faltas.items():
            for d in dados:
                self.con.execute("INSERT INTO area_logada (processo, dado, pedido_em, pedido_id) VALUES (?,?,?,?) "
                                 "ON CONFLICT(processo, dado) DO UPDATE SET pedido_em = excluded.pedido_em, pedido_id = excluded.pedido_id",
                                 (proc, d, agora, ident))
        self.con.commit()

    def area_pedido(self, ident=None):
        """O pedido pendente (ou o de `ident`): {id, criado_em, processos, lotes, ferramenta, estado, arquivo, recebidos, resumo}."""
        cols = ("id", "criado_em", "processos", "lotes", "ferramenta", "estado", "arquivo", "recebidos", "resumo")
        sql = "SELECT " + ",".join(cols) + " FROM area_pedidos " + ("WHERE id = ?" if ident else "WHERE estado = 'pendente' ORDER BY criado_em DESC LIMIT 1")  # nosec B608 - fixo
        r = self.con.execute(sql, (ident,) if ident else ()).fetchone()
        if not r:
            return None
        p = dict(zip(cols, r))
        for k, padrao in (("recebidos", []), ("resumo", {})):
            try:
                p[k] = json.loads(p[k] or "")
            except ValueError:
                p[k] = padrao
        return p

    def area_pedidos(self, limite=10):
        return [p for p in (self.area_pedido(r[0]) for r in self.con.execute(
            "SELECT id FROM area_pedidos WHERE estado IN ('respondido', 'pendente') ORDER BY criado_em DESC LIMIT ?", (int(limite),))) if p]

    def area_cancelar(self, ident):
        """Cancela o pedido: os processos dele que não tiveram resposta voltam a "ainda não pedido"."""
        self.con.execute("UPDATE area_pedidos SET estado = 'cancelado' WHERE id = ? AND estado = 'pendente'", (ident,))
        self.con.execute("UPDATE area_logada SET pedido_em = '', pedido_id = '' WHERE pedido_id = ? AND respondido_em = ''", (ident,))
        self.con.execute("DELETE FROM area_logada WHERE pedido_em = '' AND respondido_em = ''")
        self.con.commit()

    def area_registrar_resposta(self, linhas, ident=None, lotes=(), resumo=None):
        """Grava o resultado de cada processo e dado da resposta; com `ident`, junta os lotes recebidos ao pedido e o fecha
        quando todos chegaram."""
        agora = dt.datetime.now().isoformat(timespec="seconds")
        for l in linhas:
            self.con.execute("INSERT INTO area_logada (processo, dado, respondido_em, resultado, fonte, pedido_id) VALUES (?,?,?,?,?,?) "
                             "ON CONFLICT(processo, dado) DO UPDATE SET respondido_em = excluded.respondido_em, "
                             "resultado = CASE WHEN area_logada.resultado = 'encontrado' AND excluded.resultado <> 'encontrado' THEN area_logada.resultado "
                             "ELSE excluded.resultado END, fonte = CASE WHEN area_logada.resultado = 'encontrado' AND excluded.resultado <> 'encontrado' "
                             "THEN area_logada.fonte ELSE excluded.fonte END",  # revisão: um "nada" depois não apaga o que já foi achado
                             (l["processo"], l["dado"], agora, l["resultado"], str(l.get("fonte") or "")[:80], ident or ""))
        if ident:
            p = self.area_pedido(ident)
            if p:
                rec = sorted({int(x) for x in (p["recebidos"] or []) + [x for x in lotes if x]})
                estado = "respondido" if (not p["lotes"] or len(rec) >= int(p["lotes"]) or not [x for x in lotes if x]) else "pendente"
                self.con.execute("UPDATE area_pedidos SET recebidos = ?, estado = ?, resumo = ? WHERE id = ?",
                                 (json.dumps(rec), estado, json.dumps(resumo or {}, ensure_ascii=False)[:20000], ident))
        self.con.commit()

    def area_por_processo(self):
        """{processo: {estado, em}}: estado = com_dados | tentar | nada | pedido; "em" = a data da última resposta (ou do pedido)."""
        saida = {}
        for proc, res, resp, ped in self.con.execute("SELECT processo, resultado, respondido_em, pedido_em FROM area_logada"):
            s_ = saida.setdefault(proc, {"enc": 0, "td": 0, "nc": 0, "pend": 0, "em": ""})
            if res == "encontrado":
                s_["enc"] += 1
            elif res == "tentar_depois":
                s_["td"] += 1
            elif res == "nao_consta":
                s_["nc"] += 1
            elif ped:
                s_["pend"] += 1
            s_["em"] = max(s_["em"], (resp or ped or "")[:10])
        return {p: {"estado": "com_dados" if v["enc"] else "tentar" if v["td"] else "nada" if v["nc"] else "pedido", "em": v["em"]}
                for p, v in saida.items()}

    def area_tem_resposta(self):
        return self.con.execute("SELECT 1 FROM area_logada WHERE respondido_em <> '' LIMIT 1").fetchone() is not None

    def acoes(self, limite=500):
        cols = ("quando_utc", "fuso", "perfil", "acao", "alvo", "antes", "depois", "quantos")
        return [dict(zip(cols, r)) for r in self.con.execute("SELECT * FROM acoes ORDER BY quando_utc DESC LIMIT ?", (int(limite),))]

    def totais_por_situacao(self):
        return dict(self.con.execute("SELECT status, count(*) FROM leads WHERE coalesce(fora_criterio, 0) = 0 GROUP BY status").fetchall())

    def retorno(self, dias=60, limite=2000):
        """Totais por situação para a SolverONE (só quantidades): [{data, tribunal, frente, faixa_valor, situacao, qtd}]."""
        desde = (dt.date.today() - dt.timedelta(days=int(dias))).isoformat()
        linhas = self.con.execute(
            "SELECT data, coalesce(tribunal,''), coalesce(frente,''), coalesce(faixa_valor,''), status, count(*) FROM leads WHERE coalesce(fora_criterio, 0) = 0 AND "
            "data >= ? GROUP BY 1,2,3,4,5 ORDER BY 1 DESC LIMIT ?", (desde, int(limite))).fetchall()
        return [{"data": d, "tribunal": t[:40], "frente": f[:40], "faixa_valor": fx[:40], "situacao": situacao_valida(st) or "novo", "qtd": n}
                for d, t, f, fx, st, n in linhas]

    # --- Contatos (desenho dos contatos, Arquitetura 08/Nov) ---

    def guardar_contato(self, c, perfil=""):
        """Um canal de contato da empresa processada (com fonte e data). Devolve True se entrou (False se já existia)."""
        cur = self.con.execute(
            "INSERT OR IGNORE INTO contatos (processo, empresa, canal, valor, de_pessoa, fonte, data, confianca, origem, "
            "observacao, arquivo, criado_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (c["processo"], c.get("empresa", "")[:200], c["canal"], c["valor"][:300], 1 if c.get("de_pessoa") else 0,
             c.get("fonte", "")[:80], c.get("data", "")[:10], c.get("confianca", "media"), c.get("origem", "digitado"),
             c.get("observacao", "")[:300], c.get("arquivo", "")[:120], agora_utc_e_fuso()[0]))
        self.con.commit()
        return cur.rowcount == 1

    def copiar_contatos(self, origem, destinos, extras=(), perfil="", aceitar=None):
        """0.7.50 (dono, decisão 51): copia o contato DA EMPRESA de um processo para outros da mesma empresa (mesma raiz de CNPJ).
        Nunca copia contato de pessoa física, de advogado ou de escritório (pesquisa de 16/Nov: é de terceiro ou dado pessoal).
        `extras`: canais do cadastro da Receita da origem [(canal, valor)]. Devolve os ids criados (para Desfazer)."""
        fontes = [c for c in self.contatos(origem) if not c.get("de_pessoa") and c.get("validacao") != "descartado"
                  and not re.search(r"advog|escrit[oó]rio|oab", " ".join(str(c.get(k) or "") for k in ("fonte", "origem", "observacao")), re.I)
                  and (aceitar is None or aceitar(c))]
        canais = [(c["canal"], c["valor"], c.get("fonte") or "", c.get("empresa") or "") for c in fontes]
        canais += [(cn, v, "Receita Federal", "") for cn, v in extras if v]
        hoje, ids = dt.date.today().isoformat(), []
        for destino in destinos:
            if destino == origem:
                continue
            for canal, valor, fonte, empresa in canais:
                cur = self.con.execute(
                    "INSERT OR IGNORE INTO contatos (processo, empresa, canal, valor, de_pessoa, fonte, data, confianca, origem, observacao, criado_em) "
                    "VALUES (?,?,?,?,0,?,?,?,?,?,?)",
                    (destino, empresa[:200], canal, str(valor)[:300], ("copiado · " + fonte)[:80], hoje, "baixa", "copiado",
                     f"copiado de {origem} em {hoje}"[:300], agora_utc_e_fuso()[0]))
                if cur.rowcount == 1:
                    ids.append(cur.lastrowid)
        if ids:
            self.registrar_acao(perfil, "contato:copiar", origem, "", f"{len(ids)} contatos", len(ids))
        self.con.commit()
        return ids

    def desfazer_copia(self, ids):
        """Apaga só contatos copiados (origem "copiado") com estes ids."""
        ids = [int(i) for i in (ids or []) if str(i).isdigit()][:5000]
        for i in range(0, len(ids), 500):
            parte = ids[i:i + 500]
            self.con.execute(f"DELETE FROM contatos WHERE origem = 'copiado' AND id IN ({','.join('?' * len(parte))})", parte)  # nosec B608
        self.con.commit()
        return len(ids)

    def contatos_de(self, processos):
        """0.7.48: os contatos só destes processos."""
        saida, lista = [], [str(p) for p in processos][:5000]
        for i in range(0, len(lista), 500):
            for proc in lista[i:i + 500]:
                saida += self.contatos(proc)
        return saida

    def contatos(self, processo=None):
        cols = ("id", "processo", "empresa", "canal", "valor", "de_pessoa", "fonte", "data", "confianca", "origem",
                "observacao", "arquivo", "validacao", "validado_por", "validado_em", "criado_em")
        sql, args = "SELECT " + ",".join(cols) + " FROM contatos", ()  # nosec B608 - colunas fixas acima
        if processo:
            sql, args = sql + " WHERE processo = ?", (processo,)
        return [dict(zip(cols, r)) for r in self.con.execute(sql + " ORDER BY processo, canal", args)]

    def registrar_colagem(self, perfil, arquivo, aceitas, recusadas, detalhe=""):
        quando, fuso = agora_utc_e_fuso()
        self.con.execute("INSERT INTO contatos_historico VALUES (?,?,?,?,?,?,?)",
                         (quando, fuso, (perfil or "")[:120], (arquivo or "")[:120], int(aceitas), int(recusadas), (detalhe or "")[:2000]))
        self.con.commit()

    # --- Estatísticas que não se apagam ---

    def atualizar_estatisticas(self):
        """Recalcula os totais dos dias que ainda estão no Arquivo e guarda em `estatisticas_diarias`. Os dias que já não
        estão no Arquivo ficam como estavam (a tabela nunca é apagada pela limpeza)."""
        quando = dt.datetime.now().isoformat(timespec="seconds")
        linhas = self.con.execute(
            "SELECT data, coalesce(tribunal,''), coalesce(vara,''), coalesce(frente,''), coalesce(porte,''), "
            "coalesce(faixa_valor,''), count(*) FROM leads WHERE data <> '' AND coalesce(fora_criterio, 0) = 0 GROUP BY 1,2,3,4,5,6").fetchall()
        pares = sorted({(l[0], l[1]) for l in linhas})  # 0.7.18 (revisão): só o par dia+tribunal que tem ação guardada
        for d, trib in pares:
            self.con.execute("DELETE FROM estatisticas_diarias WHERE data = ? AND tribunal = ?", (d, trib))
        self.con.executemany("INSERT OR REPLACE INTO estatisticas_diarias VALUES (?,?,?,?,?,?,?,0,?)",
                             [l + (quando,) for l in linhas])
        self.con.commit()
        return len(linhas)

    def estatisticas(self, desde=None):
        cols = ("data", "tribunal", "vara", "frente", "porte", "faixa_valor", "novas", "encerradas")
        sql, args = "SELECT data, tribunal, vara, frente, porte, faixa_valor, novas, encerradas FROM estatisticas_diarias", ()
        if desde:
            sql, args = sql + " WHERE data >= ?", (desde,)
        return [dict(zip(cols, r)) for r in self.con.execute(sql + " ORDER BY data", args)]

    # --- Espaço e limpeza do dado completo ---

    def espaco(self):
        try:
            tamanho = os.path.getsize(self.caminho) if self.caminho and os.path.exists(self.caminho) else 0
        except OSError:
            tamanho = 0
        r = self.con.execute("SELECT count(*), sum(CASE WHEN bruto_limpo = 0 THEN 1 ELSE 0 END), min(data), max(data) FROM leads WHERE coalesce(fora_criterio, 0) = 0").fetchone()
        return {"bytes": tamanho, "acoes": r[0] or 0, "com_detalhe": r[1] or 0, "desde": r[2] or "", "ate": r[3] or "",
                "estatisticas_dias": self.con.execute("SELECT count(DISTINCT data) FROM estatisticas_diarias").fetchone()[0] or 0}

    def limpar_detalhe(self, meses=12, perfil="", so_nunca_abertos=False):
        """Apaga só o dado completo (trecho do Diário etc.) das ações mais velhas que `meses`; fica o resumo e as
        estatísticas. `so_nunca_abertos`: só as que continuam na situação Novo (0.7.17, banco acima de 1 GB, decisão
        14 do dono). Devolve quantas ações foram resumidas."""
        meses = int(meses or 0)
        if meses <= 0:
            return 0
        self.atualizar_estatisticas()
        limite = (dt.date.today() - dt.timedelta(days=round(meses * 30.44))).isoformat()
        feitas = 0
        sql = ("SELECT processo, dados FROM leads WHERE bruto_limpo = 0 AND primeira_vez < ? AND status = 'novo'" if so_nunca_abertos
               else "SELECT processo, dados FROM leads WHERE bruto_limpo = 0 AND primeira_vez < ?")
        for proc, dados in self.con.execute(sql, (limite,)).fetchall():
            try:
                d = json.loads(dados or "{}")
            except ValueError:
                d = {}
            r = {k: d[k] for k in _RESUMO if k in d}
            if isinstance(d.get("empresa_receita"), dict):
                r["empresa_receita"] = {k: d["empresa_receita"][k] for k in _RESUMO_RECEITA if k in d["empresa_receita"]}
            self.con.execute("UPDATE leads SET dados = ?, bruto_limpo = 1 WHERE processo = ?", (json.dumps(r, ensure_ascii=False), proc))
            feitas += 1
        if feitas:
            self.registrar_acao(perfil, "limpeza", f"mais de {meses} meses" + (", só nunca abertos" if so_nunca_abertos else ""), "", "", feitas)
        self.con.commit()
        return feitas

    # ---------- 0.7.48: limpeza automática (decisões 40 a 42; desenho DESENHO-LIMPEZA-AUTOMATICA-2026-11-14.md) ----------
    def trabalhados(self, processos=None):
        """Os processos que alguém trabalhou e que a limpeza nunca apaga: situação diferente de Novo e de Visto (Visto o programa
        marca sozinho ao abrir a ficha), contato guardado, motivo/anotação, dado digitado na ficha ou pedido/resposta da área logada."""
        t = {r[0] for r in self.con.execute("SELECT processo FROM leads WHERE lower(coalesce(status, 'novo')) NOT IN ('novo', 'visto') "
                                            "OR coalesce(motivo, '') <> ''")}
        # revisão da Operação (bloqueio): dado digitado fica em dados["manual"] = {campo: {valor, fonte, data}}; o JSON é lido de verdade
        for proc, dados in self.con.execute("SELECT processo, dados FROM leads WHERE dados LIKE '%\"manual%'"):
            try:
                d = json.loads(dados or "{}")
            except ValueError:
                t.add(proc)  # ilegível: na dúvida, não apaga
                continue
            if d.get("manual") or d.get("manual_historico"):
                t.add(proc)
        t |= {r[0] for r in self.con.execute("SELECT DISTINCT processo FROM contatos")}
        t |= {r[0] for r in self.con.execute("SELECT DISTINCT processo FROM area_logada")}
        return t if processos is None else t & set(processos)

    def limpeza_automatica(self, resumir_meses=6, apagar_meses=24, hoje=None, caminho=None):
        """Resume (tira o texto do Diário) os processos com mais de `resumir_meses`; apaga a linha dos não trabalhados com mais de
        `apagar_meses` (0 = nunca apaga), junto com as publicações do monitor daquele processo (área logada e contato fazem dele trabalhado); guarda o
        número na memória `processos_apagados` (12 meses) para não voltar como novo. As estatísticas diárias nunca são tocadas
        (são atualizadas antes). Devolve {resumidos, apagados, mantidos, bytes_antes, bytes_depois}."""
        hoje = hoje or dt.date.today()
        resumir_meses, apagar_meses = max(1, int(resumir_meses or 6)), max(0, int(apagar_meses or 0))
        if apagar_meses and apagar_meses < resumir_meses:
            apagar_meses = resumir_meses
        antes = self.espaco()["bytes"] if caminho is None else _tam(caminho)
        self.atualizar_estatisticas()
        resumidos = self.limpar_detalhe(resumir_meses, perfil="limpeza automática")
        apagados, mantidos = 0, 0
        if apagar_meses:
            limite = (hoje - dt.timedelta(days=round(apagar_meses * 30.44))).isoformat()
            velhos = [(r[0], r[1]) for r in self.con.execute("SELECT processo, coalesce(data, '') FROM leads WHERE primeira_vez < ? AND coalesce(primeira_vez, '') <> ''", (limite,))]
            trab = self.trabalhados([p for p, _ in velhos])
            mantidos = len(trab)
            for proc, data in velhos:
                if proc in trab:
                    continue
                for sql in ("DELETE FROM leads WHERE processo = ?", "DELETE FROM area_logada WHERE processo = ?",
                            "DELETE FROM publicacoes WHERE processo = ?"):
                    self.con.execute(sql, (proc,))
                self.con.execute("INSERT OR REPLACE INTO processos_apagados VALUES (?,?,?)", (proc, hoje.isoformat(), data[:10]))
                apagados += 1
            if apagados:
                self.registrar_acao("limpeza automática", "limpeza", f"mais de {apagar_meses} meses, não trabalhados", "", "", apagados)
        # a memória dos apagados vale 12 meses (Diários mais velhos que isso não são relidos)
        self.con.execute("DELETE FROM processos_apagados WHERE apagado_em < ?", ((hoje - dt.timedelta(days=366)).isoformat(),))
        self.con.execute("DELETE FROM consultas_dia WHERE data < ?", ((hoje - dt.timedelta(days=366)).isoformat(),))
        self.con.commit()
        if apagados or resumidos >= 500:  # VACUUM só quando vale a pena (leva alguns segundos num banco grande)
            self.compactar()
        depois = self.espaco()["bytes"] if caminho is None else _tam(caminho)
        return {"resumidos": resumidos, "apagados": apagados, "mantidos": mantidos, "bytes_antes": antes, "bytes_depois": depois,
                "resumir_meses": resumir_meses, "apagar_meses": apagar_meses}

    def compactar(self):
        self.con.commit()
        self.con.execute("VACUUM")

    def todos_leads(self, vara=None, desde=None, desde_diario=None, processos=None):
        """0.7.48: `processos` (lista de números) traz só esses, sem varrer o banco inteiro (pedido da área logada)."""
        if processos is not None:
            saida, lista = [], [str(p) for p in processos][:5000]
            for i in range(0, len(lista), 500):
                parte = lista[i:i + 500]
                saida += self._leads_sql(" AND processo IN (" + ",".join("?" * len(parte)) + ")", tuple(parte))
            return saida
        sql, args = "SELECT dados, status, primeira_vez, motivo, frente, bruto_limpo, status_em FROM leads WHERE coalesce(fora_criterio, 0) = 0", ()
        if vara:
            sql, args = sql + " AND vara = ?", args + (vara,)
        if desde:
            sql, args = sql + " AND primeira_vez >= ?", args + (desde,)
        if desde_diario:  # 0.7.30 (dono): pela data do processo no Diário (sem data, vale quando o programa o viu)
            # revisão da 0.7.30: data fora do formato AAAA-MM-DD (não deveria haver) vale como "quando foi lido", não some
            sql, args = sql + (" AND (CASE WHEN data GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]*' THEN substr(data, 1, 10)"
                               " ELSE substr(primeira_vez, 1, 10) END) >= ?"), args + (desde_diario,)
        return self._leads_sql(sql[len(self._SQL_LEADS):], args)

    _SQL_LEADS = "SELECT dados, status, primeira_vez, motivo, frente, bruto_limpo, status_em FROM leads WHERE coalesce(fora_criterio, 0) = 0"

    def _leads_sql(self, filtro, args):
        saida = []
        for dados, status, quando, motivo, frente, limpo, status_em in self.con.execute(self._SQL_LEADS + filtro + " ORDER BY primeira_vez DESC", args):  # nosec B608 - filtro montado só com "?"
            lead = json.loads(dados)
            lead["status"], lead["primeira_vez"] = situacao_valida(status) or "novo", quando
            lead["motivo"], lead["frente"], lead["resumido"], lead["status_em"] = motivo or "", frente or "", bool(limpo), status_em or ""
            saida.append(lead)
        return saida

    def cnpj_em_cache(self, cnpj, validade_dias):
        r = self.con.execute("SELECT quando, dados FROM cnpj WHERE cnpj = ?", (cnpj,)).fetchone()
        if r and (dt.date.today() - dt.date.fromisoformat(r[0])).days <= validade_dias:
            return json.loads(r[1])
        return None

    def guardar_cnpj(self, cnpj, dados):
        self.con.execute("INSERT OR REPLACE INTO cnpj VALUES (?,?,?)",
                         (cnpj, dt.date.today().isoformat(), json.dumps(dados, ensure_ascii=False)))
        self.con.commit()

    def registrar(self, tipo, resumo):
        self.con.execute("INSERT INTO execucoes VALUES (?,?,?)",
                         (dt.datetime.now().isoformat(timespec="seconds"), tipo, json.dumps(resumo, ensure_ascii=False)))
        self.con.commit()

    def limpar_antigos(self, dias=365):
        """Retenção: publicações do monitor e execuções mais velhas que `dias` são apagadas. As ações do Radar não são
        apagadas (0.7.13): o dado completo vira resumo (limpar_detalhe) e as estatísticas ficam para sempre."""
        if not dias or int(dias) <= 0:
            return 0
        limite = (dt.date.today() - dt.timedelta(days=int(dias))).isoformat()
        total = self.limpar_detalhe(max(1, round(int(dias) / 30.44)))
        for sql in ("DELETE FROM publicacoes WHERE visto_em < ?", "DELETE FROM execucoes WHERE quando < ?"):
            total += self.con.execute(sql, (limite,)).rowcount
        self.con.commit()
        return total

    def execucoes(self, tipo=None, limite=500):
        """As últimas execuções registradas (mais recentes primeiro): [{quando, tipo, ...resumo}]."""
        sql, args = "SELECT quando, tipo, resumo FROM execucoes", ()
        if tipo:
            sql, args = sql + " WHERE tipo = ?", (tipo,)
        saida = []
        for quando, t, resumo in self.con.execute(sql + " ORDER BY quando DESC LIMIT ?", args + (int(limite),)):
            try:
                dados = json.loads(resumo or "{}")
            except ValueError:
                dados = {"texto": resumo}
            saida.append({"quando": quando, "tipo": t, **(dados if isinstance(dados, dict) else {"dados": dados})})
        return saida

    # --- Monitor (acompanhamento dos processos do escritório) ---

    def publicacao_vista(self, chave):
        return self.con.execute("SELECT 1 FROM publicacoes WHERE chave = ?", (chave,)).fetchone() is not None

    def guardar_publicacao(self, chave, pub, visto_em=None):
        self.con.execute(
            "INSERT OR IGNORE INTO publicacoes (chave, visto_em, data, processo, dados) VALUES (?,?,?,?,?)",
            (chave, visto_em or dt.datetime.now().isoformat(timespec="seconds"), pub.get("data"), pub.get("processo"),
             json.dumps(pub, ensure_ascii=False)))
        self.con.commit()

    def publicacoes(self, limite=1000):
        saida = []
        for dados, status, visto in self.con.execute(
                "SELECT dados, status, visto_em FROM publicacoes ORDER BY data DESC, visto_em DESC LIMIT ?", (limite,)):
            pub = json.loads(dados)
            pub["status"], pub["visto_em"] = status, visto
            saida.append(pub)
        return saida

    def versao_caderno(self, tribunal, data):
        r = self.con.execute("SELECT versao FROM cadernos WHERE tribunal = ? AND data = ?", (tribunal, data)).fetchone()
        return r[0] if r else None

    # 0.7.42 (dono, 13/Nov): Diários que o CNJ não entregou (erro 5xx) ficam anotados e são lidos nas próximas leituras
    def cadernos_pendentes(self, tribunal):
        return {r[0] for r in self.con.execute("SELECT data FROM cadernos_pendentes WHERE tribunal = ?", (tribunal,))}

    def marcar_caderno_pendente(self, tribunal, data):
        self.con.execute("INSERT OR IGNORE INTO cadernos_pendentes VALUES (?,?,?)",
                         (tribunal, data, dt.datetime.now().isoformat(timespec="seconds")))
        self.con.commit()

    def tirar_caderno_pendente(self, tribunal, data):
        self.con.execute("DELETE FROM cadernos_pendentes WHERE tribunal = ? AND data = ?", (tribunal, data))
        self.con.commit()

    # 0.7.48 (desenho 1.3): varas de cada tribunal, montadas dos cadernos lidos, para dividir a consulta pública por vara
    def guardar_varas(self, tribunal, mapa):
        """`mapa` = {nome da vara: id do órgão} (djen.mapa_orgaos). Vara nova entra; a que já existe só renova a data."""
        hoje = dt.date.today().isoformat()
        self.con.executemany("INSERT OR REPLACE INTO varas VALUES (?,?,?,?)",
                             [(tribunal, str(i), str(n)[:200], hoje) for n, i in (mapa or {}).items() if str(i or "").strip() not in ("", "None")])
        self.con.commit()

    def varas(self, tribunal):
        return [(r[0], r[1]) for r in self.con.execute("SELECT id_orgao, nome FROM varas WHERE tribunal = ? ORDER BY nome", (tribunal,))]

    # 0.7.48: dias lidos pela consulta pública (uma vez por dia pendente) e a conferência quando o caderno volta
    def consulta_do_dia(self, tribunal, data):
        r = self.con.execute("SELECT quando, publicacoes, pedidos, parcial, processos, conferida_em, a_mais FROM consultas_dia "
                             "WHERE tribunal = ? AND data = ?", (tribunal, data)).fetchone()
        if not r:
            return None
        return {"quando": r[0], "publicacoes": r[1], "pedidos": r[2], "parcial": bool(r[3]), "processos": json.loads(r[4] or "[]"),
                "conferida_em": r[5] or "", "a_mais": r[6] or 0}

    def registrar_consulta_dia(self, tribunal, data, publicacoes, pedidos, parcial, processos):
        self.con.execute("INSERT OR REPLACE INTO consultas_dia (tribunal, data, quando, publicacoes, pedidos, parcial, processos) VALUES (?,?,?,?,?,?,?)",
                         (tribunal, data, dt.datetime.now().isoformat(timespec="seconds"), int(publicacoes), int(pedidos), 1 if parcial else 0,
                          json.dumps(sorted(set(processos))[:50000], ensure_ascii=False)))
        self.con.commit()

    def conferir_consulta_dia(self, tribunal, data, a_mais):
        """O caderno do dia voltou: anota a conferência e passa a fonte dos processos daquele dia de "consulta" para "caderno"."""
        c = self.consulta_do_dia(tribunal, data)
        if not c or c["conferida_em"]:
            return None
        self.con.execute("UPDATE consultas_dia SET conferida_em = ?, a_mais = ? WHERE tribunal = ? AND data = ?",
                         (dt.datetime.now().isoformat(timespec="seconds"), int(a_mais), tribunal, data))
        procs = c["processos"]
        for i in range(0, len(procs), 500):
            parte = procs[i:i + 500]
            marcas = ",".join("?" * len(parte))
            mudar = []
            for proc, dados in self.con.execute(f"SELECT processo, dados FROM leads WHERE processo IN ({marcas})", parte):  # nosec B608
                try:
                    d = json.loads(dados or "{}")
                except ValueError:
                    continue
                if d.get("fonte_leitura") == "consulta":
                    d["fonte_leitura"], d["caderno_pendente"] = "caderno", False
                    mudar.append((json.dumps(d, ensure_ascii=False), proc))
            self.con.executemany("UPDATE leads SET dados = ? WHERE processo = ?", mudar)
        self.con.commit()
        return c

    def consultas_sem_conferencia(self, tribunal):
        return {r[0] for r in self.con.execute("SELECT data FROM consultas_dia WHERE tribunal = ? AND conferida_em = ''", (tribunal,))}

    def guardar_caderno(self, tribunal, data, versao):
        self.con.execute("INSERT OR REPLACE INTO cadernos VALUES (?,?,?,?)",
                         (tribunal, data, str(versao), dt.datetime.now().isoformat(timespec="seconds")))
        self.con.commit()

    # --- Rodadas (cada vez que o monitor roda) ---

    def registrar_rodada(self, rodada):
        self.con.execute(
            "INSERT OR REPLACE INTO rodadas VALUES (?,?,?,?,?,?,?)",
            (rodada["id"], rodada["quando"], rodada.get("modo", ""), int(rodada.get("conferidas") or 0),
             int(rodada.get("novas_processos") or 0), int(rodada.get("novas_acoes") or 0),
             json.dumps(rodada.get("detalhes") or {}, ensure_ascii=False)))
        self.con.commit()

    def rodadas(self, desde=None, limite=200):
        sql, args = "SELECT id, quando, modo, conferidas, novas_processos, novas_acoes, detalhes FROM rodadas", ()
        if desde:
            sql, args = sql + " WHERE quando >= ?", (desde,)
        saida = []
        for r in self.con.execute(sql + " ORDER BY quando DESC LIMIT ?", args + (limite,)):
            saida.append({"id": r[0], "quando": r[1], "modo": r[2], "conferidas": r[3], "novas_processos": r[4],
                          "novas_acoes": r[5], "detalhes": json.loads(r[6] or "{}")})
        return saida

    def publicacoes_desde(self, desde):
        return [p for p in self.publicacoes(5000) if (p.get("visto_em") or "") >= desde]


def _contar(valores):
    c = {}
    for v in valores:
        c[v] = c.get(v, 0) + 1
    return c
