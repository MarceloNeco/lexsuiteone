"""A pasta compartilhada (Google Drive para computador, OneDrive, Dropbox): onde o robô deixa a planilha e a página
e de onde lê o controle e as atualizações. Nada de senha: é só uma pasta do computador que o Drive sincroniza."""

import json
import os
import platform
import shutil

from . import config, planilha, preferencias

NOME_RADAR = preferencias.NOME_ARQUIVO  # 0.7.33: Radar, Arquivo, Contatos, Critérios desta leitura, Como usar, Histórico + (ocultas) Controle, Saúde, Sobre
NOME_PAGINA = "Retrato da última leitura.html"  # cópia da tela (0.7.14; antes "Lista para abrir no celular.html")
NOMES_PAGINA_ANTIGOS = ("LexSuiteONE - Radar.html", "Lista para abrir no celular.html")
NOME_PAGINA_ANTIGO = NOMES_PAGINA_ANTIGOS[0]
NOME_HISTORICO = "Histórico de leituras"
AVISO_RADAR = ("ATENÇÃO: esta planilha é regravada pelo {produto} a cada leitura. Pode filtrar e ordenar à vontade; "
               "para anotar ou mexer, use \"Gerar uma cópia\" no programa (o que for digitado aqui se perde na próxima leitura).")
SUBPASTA_ATUALIZACAO = "atualizacao"


def candidatas():
    """Pastas do Google Drive para computador que existem aqui ("Meu Drive" / "My Drive"), na ordem de probabilidade.
    OneDrive e Dropbox ficam de fora da lista (não testados; "sob consulta"); dá para escolher qualquer pasta à mão."""
    home = os.path.expanduser("~")
    opcoes = []
    for base in (home, os.path.join(home, "Google Drive")):
        for nome in ("Meu Drive", "My Drive"):
            opcoes.append(os.path.join(base, nome))
    if os.name == "nt":
        for letra in "DEFGHIJKLMNOPQRSTUVWXYZ":
            for nome in ("Meu Drive", "My Drive"):
                opcoes.append(f"{letra}:\\{nome}")
    achadas = []
    for p in opcoes:
        if os.path.isdir(p) and p not in achadas:
            achadas.append(p)
    return achadas


def nuvens(gdrive=None):
    """0.7.21 (decisão do dono): pastas de nuvem sincronizadas que existem neste Windows, para a tela oferecer como atalho
    da "pasta compartilhada": Google Drive para computador (Meu Drive / My Drive) e OneDrive. [{tipo, caminho}]."""
    achadas = [{"tipo": "gdrive", "caminho": p} for p in (candidatas() if gdrive is None else gdrive)]
    home = os.path.expanduser("~")
    opcoes = [os.environ.get(v, "") for v in ("OneDriveCommercial", "OneDriveConsumer", "OneDrive")]
    try:
        opcoes += [os.path.join(home, n) for n in sorted(os.listdir(home)) if n.lower().startswith("onedrive")]
    except OSError:
        pass
    vistos = set()
    for p in opcoes:
        if p and os.path.isdir(p) and os.path.normcase(os.path.abspath(p)) not in vistos:
            vistos.add(os.path.normcase(os.path.abspath(p)))
            achadas.append({"tipo": "onedrive", "caminho": p})
    return achadas


def no_google_drive(pasta):
    """True se a pasta fica dentro do Meu Drive / My Drive do Google Drive para computador."""
    partes = [x.lower() for x in os.path.normpath(str(pasta or "")).replace("\\", "/").split("/")]
    return "meu drive" in partes or "my drive" in partes


def subpasta_para(cfg, nome_produto="RADAR JUDICIAL"):
    """Nome da pasta da planilha. Quem já tinha pasta escolhida continua com a dela ("LexSuiteONE"); instalação nova
    usa "<produto> - planilha", para não confundir com a pasta do programa (C:\\LexSuiteONE)."""
    c = cfg.get("compartilhar") or {}
    if c.get("pasta"):
        return c.get("subpasta") or "LexSuiteONE"
    return f"{nome_produto} - planilha"


def pasta_base(cfg):
    c = cfg.get("compartilhar") or {}
    return os.path.join(c["pasta"], c.get("subpasta") or "LexSuiteONE") if c.get("pasta") else ""


def pasta_atualizacao(cfg):
    base = pasta_base(cfg)
    return os.path.join(base, SUBPASTA_ATUALIZACAO) if base else ""


def testar(pasta, subpasta="LexSuiteONE", criar=False, leve=False):
    """Confere se dá para criar a subpasta e gravar nela (com criar=True, cria também a pasta escolhida).
    Com leve=True (0.7.19, teste automático da tela) só confere, sem criar nem gravar nada (no Drive, gravar e apagar
    um arquivo de teste a cada clique gera sincronização à toa). Devolve (ok, mensagem)."""
    if pasta and not os.path.isdir(pasta) and criar:
        try:
            os.makedirs(pasta, exist_ok=True)
        except OSError as e:
            return False, f"Não consegui criar a pasta {pasta} ({e.__class__.__name__})."
    if not pasta or not os.path.isdir(pasta):
        return False, "Essa pasta ainda não existe neste computador."
    alvo = os.path.join(pasta, subpasta)
    existia = os.path.isdir(alvo)
    if leve and not criar:
        if os.access(alvo if existia else pasta, os.W_OK):
            return True, f"Pronto: a planilha vai ficar em {alvo}."
        return False, f"Sem permissão para gravar em {alvo if existia else pasta}."
    try:
        os.makedirs(alvo, exist_ok=True)
        prova = os.path.join(alvo, "teste-lexsuite.txt")
        with open(prova, "w", encoding="utf-8") as f:
            f.write("ok\n")
        os.remove(prova)
        if not existia:
            os.rmdir(alvo)  # só testar não deixa pasta vazia para trás; ela nasce ao salvar
    except OSError as e:
        return False, f"Não consegui gravar em {alvo} ({e.__class__.__name__})."
    return True, f"Pronto: a planilha vai ficar em {alvo}."


def _sobre(cfg, versao, chave_impressao, ultima):
    return [["Item", "Valor"],
            ["Produto", "LexSuiteONE · JUDICIAL (Radar Trabalhista)"], ["Versão", versao], ["Escritório", cfg.get("escritorio", "")],
            ["Computador", platform.node()], ["Sistema", f"{platform.system()} {platform.release()}"],
            ["Python", platform.python_version()], ["Pasta do robô", cfg.get("_pasta_robo", "")],
            ["Tribunais", ", ".join((cfg.get("radar") or {}).get("tribunais") or [])],
            ["Última rodada", ultima], ["Chave de atualização (impressão)", chave_impressao or "sem chave: atualização desligada"],
            ["Suporte", preferencias.SUPORTE]]


def _abas_editaveis(caminho, aviso=print):
    """Lê da planilha existente as abas que o escritório edita, para preservá-las. Devolve (abas, ok).
    ok=False quando o arquivo existe mas não pôde ser lido (em uso, corrompido): aí NÃO se regrava."""
    if not os.path.exists(caminho):
        return preferencias.abas_padrao(), True
    try:
        doc = planilha.ler_xlsx(caminho, so_abas=preferencias.ABAS_EDITAVEIS)
    except Exception as e:
        aviso(f"  Planilha em uso ou ilegível ({e.__class__.__name__}); deixo como está nesta rodada.")
        return [], False
    atuais = {a["nome"]: a for a in doc["abas"]}
    abas = []
    for padrao in preferencias.abas_padrao():
        existente = atuais.get(padrao["nome"])
        if existente and existente["linhas"]:
            linhas = [list(l) for l in existente["linhas"]]
            abas.append({"nome": padrao["nome"], "linhas": linhas, "oculta": padrao.get("oculta", False), "larguras": padrao.get("larguras")})
        else:
            abas.append(padrao)
    return abas, True


def _copia_antes_0733(base, frente, caminho, aviso=print):
    """Revisão da 0.7.33 (bloqueio 1a): antes da primeira regravação que tira as abas Preferências e Exclusões, a planilha
    vai inteira para "Cópias de segurança/antes da 0.7.33/" (uma vez; a primeira cópia nunca é substituída). A migração
    dos outros computadores também lê dessa cópia. Se a cópia falhar, NÃO regrava (devolve False)."""
    import shutil
    destino = preferencias.copia_antes_0733(base, frente)
    if not destino or os.path.exists(destino) or not os.path.exists(caminho):
        return True
    try:
        tem = preferencias._ler_abas_antigas(caminho)[2]
    except Exception as e:  # noqa: BLE001 - em uso ou ilegível: não regrava agora
        aviso(f"  Planilha em uso ou ilegível ({e.__class__.__name__}); deixo como está nesta rodada.")
        return False
    if not tem:
        return True
    try:
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        shutil.copyfile(caminho, destino + ".tmp")
        os.replace(destino + ".tmp", destino)
    except OSError as e:
        aviso(f"  Não consegui guardar a cópia de segurança \"antes da 0.7.33\" ({e.__class__.__name__}): a planilha não foi "
              "regravada, para nada se perder. A lista está salva.")
        return False
    aviso(f"  Cópia da planilha como era antes da 0.7.33 guardada em Cópias de segurança ({os.path.basename(destino)}).")
    return True


def criar_se_faltar(cfg, versao="", pasta_robo="", aviso=print):
    """Cria a planilha única com o Radar vazio e as abas editáveis padrão. Nunca sobrescreve a que existe."""
    base = pasta_base(cfg)
    if not base:
        return ""
    os.makedirs(base, exist_ok=True)
    preferencias.migrar_nome(base, aviso)
    os.makedirs(os.path.join(base, "Cópias de segurança"), exist_ok=True)
    if preferencias.nome_pendente(base):
        return os.path.join(base, preferencias.NOME_ANTIGO)
    caminho = os.path.join(base, NOME_RADAR)
    if os.path.exists(caminho):
        return caminho
    cabecalho = ["Hora", "Tribunal", "Vara", "Processo", "Rito", "Distribuída em", "Empresa(s)", "CNPJ"]
    planilha.escrever_xlsx(caminho, [{"nome": "Radar", "linhas": [cabecalho], "larguras": [8, 9, 34, 26, 12, 12, 40, 18]}]
                           + preferencias.abas_padrao()
                           + [{"nome": "Sobre", "linhas": _sobre(dict(cfg, _pasta_robo=pasta_robo), versao, "", ""), "oculta": True, "larguras": [30, 80]}],
                           so_leitura_recomendado=True, marcar=True)  # 0.7.21 (revisão): já nasce só para leitura
    aviso(f"  Criei a planilha: {caminho}")
    return caminho


def _linhas_lista(itens, colunas, linha_csv):
    cabecalho = [titulo for titulo, _ in colunas] + ["Excluída (motivo)", "Ações na janela"]
    linhas = [cabecalho]
    for it in itens:
        l = linha_csv(it)
        linhas.append([_celula(l.get(chave)) for _, chave in colunas] + [it.get("excluida") or "", it.get("acoes_na_janela", "")])
    return linhas


def _destacar(linhas, chaves, minimo):
    if "valor_causa" not in chaves or not minimo:
        return set()
    j = chaves.index("valor_causa")
    return {n for n, l in enumerate(linhas[1:], 1) if isinstance(l[j], (int, float)) and not isinstance(l[j], bool) and l[j] >= minimo}


def gravar_radar(cfg, pagina, banco, versao, colunas, linha_csv, chave_impressao="", pasta_robo="", aviso=print, arquivo=None,
                 frente="trabalhista", itens=None, aviso_tamanho="", processos=None, criterios=None):
    """Regrava a planilha da frente (0.7.16: uma por frente): aba Radar (a lista), Arquivo, Contatos, Critérios desta
    leitura (0.7.33), a aba Controle oculta preservada e as abas Histórico, Saúde e Sobre. Também copia a página HTML.
    `itens`: as linhas da aba Radar (padrão: as da página). `processos`: só os contatos desses processos.
    Devolve o caminho da planilha, ou '' se não houver pasta ou se a planilha estiver em uso."""
    base = pasta_base(cfg)
    if not base:
        return ""
    os.makedirs(base, exist_ok=True)
    os.makedirs(os.path.join(base, "Cópias de segurança"), exist_ok=True)
    preferencias.migrar_nome(base, aviso)
    if frente == "trabalhista" and preferencias.nome_pendente(base):  # 0.7.16: nunca cria a nova sem as abas editadas
        aviso(f"  A planilha {preferencias.NOME_ANTIGO} está aberta: feche-a para o RADAR trocar o nome e gravar. A lista está salva.")
        return ""
    caminho = os.path.join(base, preferencias.NOMES_FRENTE.get(frente) or NOME_RADAR)
    editaveis, ok = _abas_editaveis(caminho, aviso)
    if not ok:
        return ""
    if not _copia_antes_0733(base, frente, caminho, aviso):
        return ""
    linhas = _linhas_lista(pagina.get("itens") or [] if itens is None else itens, colunas, linha_csv)
    # 0.7.13: a aba Log mostra o histórico de leituras, uma linha por tribunal e por tentativa, visível ao escritório.
    from . import causas
    rotulo = {"ok": "Lido", "ainda_nao_liberado_3h": "Diário de hoje só às 3h (não é erro)", "nao_publicado": "Ainda não publicado",
              "governo_fora": "Site do CNJ fora do ar", "bloqueio_fora_do_brasil": "Fora do Brasil", "sem_internet": "Sem internet",
              "erro_do_programa": "Erro do programa", "interrompida": "Interrompida a pedido"}
    log = [["Quando (hora local e fuso)", "Origem", "Tribunal", "Dias pedidos", "Resposta do site", "Situação", "O que o programa fez",
            "Duração (s)", "Versão", "Explicação"]]
    for e in banco.execucoes("tentativa", 1000):
        c = e.get("causa", "")
        log.append([e.get("quando_local") or e.get("quando", ""), e.get("origem", ""), e.get("tribunal", ""), e.get("dias_pedidos", ""),
                    e.get("http", ""), rotulo.get(c, c), e.get("fez", ""), e.get("duracao", ""), e.get("versao", ""),
                    "" if c == "ok" else causas.mensagem(c)])
    for e in banco.execucoes("radar", 200):  # rodadas antigas (antes da 0.7.13) e o resumo de cada rodada
        log.append([e.get("quando", ""), "resumo da rodada", ", ".join(e.get("tribunais") or []), "", "",
                    "Lido" if e.get("resultado") == "ok" else (rotulo.get(e.get("causa", ""), "Parou")),
                    f"{e.get('lidas', '')} publicações, {e.get('novas', '')} processos novos, {e.get('com_cnpj', '')} com CNPJ",
                    e.get("duracao", ""), e.get("versao", ""), causas.mensagem(e["causa"]) if e.get("causa") else (e.get("erro") or "")])
    saude = [["Quando", "Fonte", "Situação", "Detalhe"]]
    for e in banco.execucoes("saude", 300):
        saude.append([e.get("quando", ""), e.get("fonte", ""), e.get("situacao", ""), e.get("detalhe", "")])
    ultima = log[1][0] if len(log) > 1 else ""
    chaves = [chave for _, chave in colunas]
    moeda = [chaves.index(k) for k in ("capital_social", "valor_causa") if k in chaves]
    minimo = float(pagina.get("valor_minimo") or 0)
    produto = _nome_produto(pasta_robo)
    larguras = [14, 11, 8, 9, 34, 26, 12, 12, 40, 18, 22, 16, 36, 20, 18, 16, 28, 40, 15, 16, 12, 30, 40, 10, 40, 30, 30, 10]
    abas = [{"nome": "Radar", "linhas": linhas, "visual": True, "filtro": True, "moeda": moeda, "destacar": _destacar(linhas, chaves, minimo),
             "aviso": ((aviso_tamanho + " ") if aviso_tamanho else "") + AVISO_RADAR.format(produto=produto), "larguras": larguras}]
    if arquivo is not None:  # 0.7.16: últimos N dias + todo processo trabalhado; o resto fica no programa e nas cópias
        la = _linhas_lista(arquivo, colunas, linha_csv)
        abas.append({"nome": "Arquivo", "linhas": la, "visual": True, "filtro": True, "moeda": moeda, "destacar": _destacar(la, chaves, minimo),
                     "aviso": "Arquivo: o que não está na aba Radar, dos últimos dias, e todo processo trabalhado (Em análise, Em contato, "
                              "Virou cliente), inclusive arquivados. O resto continua no " + produto + " (tela Arquivo) e nas cópias de segurança. Só para consulta.",
                     "larguras": larguras})
    contatos = [["Processo", "Empresa", "Canal", "Contato", "De pessoa (sócio)", "Fonte", "Data", "Confiança", "Origem", "Validação", "Observação"]]
    for c in (banco.contatos() if hasattr(banco, "contatos") else []):
        if processos is not None and c["processo"] not in processos:
            continue
        contatos.append([c["processo"], c["empresa"], c["canal"], c["valor"], "sim" if c["de_pessoa"] else "", c["fonte"], c["data"],
                         c["confianca"], c["origem"], c["validacao"], c["observacao"]])
    abas.append({"nome": "Contatos", "linhas": contatos, "visual": True, "filtro": True,
                 "aviso": "Contatos encontrados (Receita, área logada ou digitados), sempre com a fonte e a data. Os da Receita também estão na aba Radar.",
                 "larguras": [26, 34, 11, 34, 10, 20, 11, 10, 12, 12, 40]})
    if criterios is not None:  # 0.7.33: com que critérios esta pessoa gravou (só leitura; o programa não lê esta aba)
        abas.append({"nome": "Critérios desta leitura", "linhas": preferencias.linhas_criterios(criterios, (cfg.get("usuario") or {}).get("nome", "")),
                     "visual": True, "larguras": [52, 40]})
    planilha.escrever_xlsx(caminho, abas + [dict(a, visual=True) for a in editaveis] + [
        {"nome": NOME_COMO_USAR, "linhas": como_usar(produto), "visual": True, "larguras": [24, 70, 70]},
        {"nome": NOME_HISTORICO, "linhas": log, "visual": True, "filtro": True, "larguras": [24, 16, 10, 22, 10, 26, 40, 10, 8, 60]},
        {"nome": "Saúde", "linhas": saude, "oculta": True, "larguras": [20, 18, 10, 80]},
        {"nome": "Sobre", "linhas": _sobre(dict(cfg, _pasta_robo=pasta_robo), versao, chave_impressao, ultima), "oculta": True, "larguras": [30, 80]},
    ], so_leitura_recomendado=True, marcar=True)
    html = os.path.join(pasta_robo, "saida", "radar", "radar.html") if pasta_robo else ""
    if html and os.path.exists(html):
        shutil.copyfile(html, os.path.join(base, NOME_PAGINA))
        for nome in NOMES_PAGINA_ANTIGOS:  # os nomes antigos confundiam (pareciam outra planilha)
            antiga = os.path.join(base, nome)
            if os.path.exists(antiga):
                try:
                    os.remove(antiga)
                except OSError:
                    pass
    aviso(f"  Planilha compartilhada: {caminho}")
    return caminho


NOME_COMO_USAR = "Como usar"


def gerar_copia(cfg, agora=None):
    """0.7.14: cópia da planilha para o escritório trabalhar (anotar, mexer), na subpasta "Cópias", sem a proteção, sem
    a marca de somente leitura e com o aviso trocado. O RADAR nunca mexe nas cópias. Devolve (ok, caminho ou motivo)."""
    import datetime as _dt
    import re as _re
    import zipfile as _zip
    base = pasta_base(cfg)
    origem = preferencias.caminho(base) if base else ""
    if not origem or not os.path.exists(origem):
        return False, "A planilha ainda não existe: faça uma leitura primeiro."
    agora = agora or _dt.datetime.now()
    destino_pasta = os.path.join(base, PASTA_COPIAS_TRABALHO)
    os.makedirs(destino_pasta, exist_ok=True)
    destino = os.path.join(destino_pasta, f"{os.path.splitext(NOME_RADAR)[0]} - cópia {agora:%Y-%m-%d %Hh%Mm%S}.xlsx")
    from xml.sax.saxutils import escape as _esc
    nome_esc = planilha._limpa(str((cfg.get("conta") or {}).get("escritorio_licenca") or cfg.get("escritorio") or "")).replace("\x7f", "").strip()[:80]
    dono = f"do escritório {nome_esc}" if nome_esc else "do escritório"  # 0.7.21 (dono): o nome do escritório na faixa
    marca_copia = _esc(f"Cópia de trabalho gerada em {config.data_curta(agora)} às {agora:%H:%M}. Este arquivo é {dono}: pode ser editado "
                       f"livremente e não é alterado pelo RADAR. Para os dados mais recentes, gere uma nova cópia.")
    try:
        with _zip.ZipFile(origem) as zin, _zip.ZipFile(destino, "w", _zip.ZIP_DEFLATED) as zout:
            for info in zin.infolist():
                dados = zin.read(info.filename)
                if info.filename.startswith("xl/worksheets/") or info.filename == "xl/workbook.xml":
                    t = dados.decode("utf-8")
                    t = _re.sub(r"<sheetProtection[^>]*/>", "", t)
                    t = _re.sub(r"<fileSharing[^>]*/>", "", t)
                    t = _re.sub(r"(<c r=\"A1\" s=\")7(\" t=\"inlineStr\"><is><t[^>]*>)[^<]*(</t>)",
                                lambda m: m.group(1) + "8" + m.group(2) + marca_copia + m.group(3), t)  # 0.7.18: faixa verde
                    dados = t.encode("utf-8")
                zout.writestr(info, dados)
    except (OSError, _zip.BadZipFile) as e:
        return False, f"Não consegui copiar a planilha ({e.__class__.__name__})."
    return True, destino


PASTA_COPIAS_TRABALHO = "Cópias da planilha"  # 0.7.18 (antes "Cópias"); "Cópias de segurança" são as do sistema


def _nome_produto(pasta_robo):
    try:
        with open(os.path.join(pasta_robo, "marca.json"), encoding="utf-8") as f:
            return " ".join(str(json.load(f).get("nome") or "").split())[:40] or "RADAR JUDICIAL"
    except (OSError, ValueError, AttributeError, TypeError):
        return "RADAR JUDICIAL"


def como_usar(produto="RADAR JUDICIAL"):
    """Aba visível com o passo a passo da planilha, em português e inglês. Não tem dado de cliente."""
    return [
        ["Assunto / Topic", "Como fazer", "How to"],
        ["O que é esta planilha", f"O {produto} grava aqui, sozinho, a lista de processos novos a cada leitura. Não precisa "
         "copiar nem compartilhar nada: a planilha se atualiza no lugar.",
         f"{produto} writes the list of new lawsuits here by itself after every reading. Nothing to copy or share: "
         "the file updates in place."],
        ["Filtrar", "Clique na setinha do cabeçalho (Tribunal, Setor, Porte, Cidade/UF...) e marque o que quer ver.",
         "Click the small arrow in the header (Court, Sector, Size, City...) and tick what you want to see."],
        ["Ordenar pelo valor", "Na setinha de \"Valor da causa\", escolha \"Classificar do maior para o menor\".",
         "On the \"Valor da causa\" arrow, choose \"Sort largest to smallest\"."],
        ["Destaque em latão", "O valor da causa com fundo latão claro está acima do valor mínimo de quem gravou (aba Critérios desta leitura).",
         "A claim value with a light brass background is above the minimum value of whoever saved it (Criteria of this reading tab)."],
        ["Excluir uma empresa", "No programa: Configurações → Destaques e exclusões → Empresas excluídas. Os critérios são de cada "
         "pessoa, no computador dela, por área; a planilha não guarda critérios e traz só a aba Critérios desta leitura, para consulta.",
         "In the program: Settings → Highlights and exclusions → Excluded companies. Criteria belong to each person, on their computer, by area; "
         "the spreadsheet keeps no criteria and only has the Criteria of this reading tab, for reference."],
        ["Planilha aberta", "Se a planilha estiver aberta no Excel na hora da leitura, o programa avisa e grava depois. "
         "Feche e use o botão \"Gravar a planilha agora\".",
         "If the file is open in Excel during a reading, the program warns you and writes it later. Close it and use "
         "the \"Write the spreadsheet now\" button."],
        ["Google Planilhas", "Funciona também: abra pelo Google Drive. Os filtros e as cores vêm junto.",
         "It also works in Google Sheets: open it from Google Drive. Filters and colours come along."],
    ]


def _celula(v):
    if isinstance(v, list):
        return " | ".join(str(x) for x in v)
    if isinstance(v, bool):
        return "sim" if v else ""
    return "" if v is None else v
