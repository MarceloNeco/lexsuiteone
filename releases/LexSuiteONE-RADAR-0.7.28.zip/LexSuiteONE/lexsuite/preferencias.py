"""Preferências e controle do escritório: as abas Preferências, Exclusões e Controle (oculta) da planilha única
<pasta compartilhada>/LexSuiteONE/LexSuiteONE.xlsx. O escritório edita essas abas; o robô lê antes de cada rodada
e as preserva quando regrava a planilha (ver compartilhar.gravar_radar).
"""

import datetime as dt
import os
import re

from . import classificar as cl
from . import planilha

# 0.7.16: uma planilha por frente, na mesma pasta (decisão de 09/Nov, documentacao/DESENHO-PLANILHA-GRANDE.md). A frente
# trabalhista é a de hoje; as outras nascem sozinhas quando houver processos delas. A planilha única antiga
# (LexSuiteONE.xlsx) vira a trabalhista na primeira leitura, com as abas editadas.
NOMES_FRENTE = {"trabalhista": "LexSuiteONE - Trabalhista.xlsx", "tributario": "LexSuiteONE - Tributário.xlsx",
                "civel": "LexSuiteONE - Cível.xlsx", "empresarial": "LexSuiteONE - Empresarial.xlsx"}
NOME_ARQUIVO = NOMES_FRENTE["trabalhista"]
NOME_ANTIGO = "LexSuiteONE.xlsx"

PADRAO = {"valor_minimo": 100000, "minimo_acoes": 1, "janela_dias": 30, "teto_capital_gigante": 50000000,
          "esconder_gigantes": False, "esconder_excluidas": True, "mostrar_socios": True,
          "dias_arquivo": 90, "limite_linhas": 60000}
CHAVES = {
    "Valor mínimo da causa (R$)": "valor_minimo",
    "Mínimo de ações da mesma empresa": "minimo_acoes",
    "Janela do mínimo de ações (dias)": "janela_dias",
    "Capital social que indica jurídico próprio (R$)": "teto_capital_gigante",
    "Esconder jurídico próprio provável": "esconder_gigantes",
    "Esconder clientes e exclusões": "esconder_excluidas",
    "Mostrar sócios e administradores": "mostrar_socios",
    "Dias na aba Arquivo": "dias_arquivo",
    "Limite de linhas da planilha": "limite_linhas",
}
LINHAS_PREFERENCIAS = [
    ["Ajuste", "Valor", "Como usar"],
    ["Valor mínimo da causa (R$)", 100000, "Filtro \"Acima de\" na tela e na planilha. Ações abaixo continuam na lista."],
    ["Mínimo de ações da mesma empresa", 1, "Ex.: 3 = só destacar empresa com 3 ou mais ações novas na janela de dias. 1 = todas."],
    ["Janela do mínimo de ações (dias)", 30, "Quantos dias para trás contar as ações da mesma empresa."],
    ["Capital social que indica jurídico próprio (R$)", 50000000, "Acima disso a empresa é marcada \"jurídico próprio provável\" e vai para o fim da lista."],
    ["Esconder jurídico próprio provável", "não", "sim ou não."],
    ["Esconder clientes e exclusões", "sim", "sim ou não. A aba Exclusões lista quem não deve aparecer."],
    ["Mostrar sócios e administradores", "sim", "sim ou não. São nomes de pessoas do cadastro público da Receita; se o escritório não precisa, desligue."],
    ["Dias na aba Arquivo", 90, "A aba Arquivo mostra os últimos N dias e todo processo trabalhado (Em análise, Em contato, Virou cliente). O resto continua no programa e na tela Arquivo."],
    ["Limite de linhas da planilha", 60000, "Acima de 80% o RADAR avisa; a 100% guarda uma cópia de segurança e enxuga a aba Arquivo sozinho. Mais linhas deixam o Excel lento."],
]
LINHAS_EXCLUSOES = [
    ["Nome ou CNPJ", "Motivo"],
    ["(exemplo, pode apagar) Empresa Exemplo Ltda", "cliente atual"],
]
# Contato de atendimento do JUDICIAL. integracao@ é só para sistemas (compartilhamento do Drive), nunca para pessoas.
SUPORTE = "judicial@solverone.com.br"
SISTEMAS = "integracao@solverone.com.br"

LINHAS_CONTROLE = [
    ["Chave", "Valor", "O que faz"],
    ["ativo", "sim", "não = o robô não roda e mostra a mensagem abaixo."],
    ["validade", "", "aaaa-mm-dd. Depois dessa data o robô para e avisa."],
    ["versao_minima", "", "Se a versão instalada for menor, o robô pede atualização antes de rodar."],
    ["mensagem", "", "Texto mostrado na tela do escritório (avisos do suporte)."],
    ["suporte", SUPORTE, "Contato do suporte (atendimento a pessoas)."],
]


def caminho(pasta_base, frente="trabalhista"):
    """Caminho da planilha da frente. Antes, troca o nome da planilha única antiga, se for o caso."""
    if not pasta_base:
        return ""
    migrar_nome(pasta_base)
    if frente == "trabalhista" and nome_pendente(pasta_base):  # a antiga está aberta: continua valendo até trocar de nome
        return os.path.join(pasta_base, NOME_ANTIGO)
    return os.path.join(pasta_base, NOMES_FRENTE.get(frente) or NOME_ARQUIVO)


def nome_pendente(pasta_base):
    """True quando a planilha antiga ainda não pôde trocar de nome (aberta no Excel): nada pode criar a nova, senão as
    abas editadas pelo escritório ficariam na antiga, esquecida."""
    return bool(pasta_base) and os.path.exists(os.path.join(pasta_base, NOME_ANTIGO)) and not os.path.exists(os.path.join(pasta_base, NOME_ARQUIVO))


def migrar_nome(pasta_base, aviso=None):
    """LexSuiteONE.xlsx (até a 0.7.15) vira "LexSuiteONE - Trabalhista.xlsx". Se estiver aberta no Excel, fica para a
    próxima vez. Devolve True quando trocou."""
    antigo, novo = os.path.join(pasta_base, NOME_ANTIGO), os.path.join(pasta_base, NOME_ARQUIVO)
    if not os.path.exists(antigo) or os.path.exists(novo):
        return False
    try:  # 0.7.17: antes de trocar o nome, guarda uma cópia da antiga em "Cópias de segurança" (uma vez só)
        import shutil
        pasta_c = os.path.join(pasta_base, "Cópias de segurança", "antes da troca de nome")
        os.makedirs(pasta_c, exist_ok=True)
        if not os.path.exists(os.path.join(pasta_c, NOME_ANTIGO)):
            shutil.copy2(antigo, os.path.join(pasta_c, NOME_ANTIGO))
    except OSError:
        pass
    try:
        os.replace(antigo, novo)
    except OSError:
        if aviso:
            aviso(f"  A planilha {NOME_ANTIGO} está aberta: o novo nome ({NOME_ARQUIVO}) fica para a próxima leitura.")
        return False
    if aviso:
        aviso(f"  A planilha passou a se chamar {NOME_ARQUIVO} (uma por frente); as abas editadas foram mantidas.")
    return True


def planilhas_existentes(pasta_base):
    """[(frente, caminho)] das planilhas que já existem na pasta, na ordem das frentes."""
    if not pasta_base:
        return []
    migrar_nome(pasta_base)
    saida = [(f, os.path.join(pasta_base, n)) for f, n in NOMES_FRENTE.items() if os.path.exists(os.path.join(pasta_base, n))]
    if nome_pendente(pasta_base):
        saida.insert(0, ("trabalhista", os.path.join(pasta_base, NOME_ANTIGO)))
    return saida


ABAS_EDITAVEIS = ("Preferências", "Exclusões", "Controle")


def abas_padrao():
    """As três abas como nascem na primeira vez (o escritório edita depois)."""
    return [
        {"nome": "Preferências", "linhas": [list(l) for l in LINHAS_PREFERENCIAS], "larguras": [46, 16, 80]},
        {"nome": "Exclusões", "linhas": [list(l) for l in LINHAS_EXCLUSOES], "larguras": [48, 50]},
        {"nome": "Controle", "linhas": [list(l) for l in LINHAS_CONTROLE], "oculta": True, "larguras": [18, 36, 70]},
    ]


def _sim(v):
    return cl.sem_acento(str(v if v is not None else "")).strip().lower() in ("sim", "s", "yes", "true", "1", "x", "verdadeiro")


def _numero(v, padrao):
    if isinstance(v, bool):
        return padrao
    if isinstance(v, (int, float)):
        return v
    t = str(v or "").strip().replace("R$", "").replace(" ", "")
    if not t:
        return padrao
    if "," in t:  # formato brasileiro: 1.234,56
        t = t.replace(".", "").replace(",", ".")
    elif t.count(".") > 1:  # 1.234.567 sem centavos
        t = t.replace(".", "")
    try:
        n = float(t)
        return int(n) if n == int(n) else n
    except (ValueError, OverflowError):  # revisão da 0.7.28: "1e400", "inf" e "NaN" voltam ao padrão
        return padrao


def versao_tupla(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v or ""))[:3]) or (0,)


LIMITES = {"valor_minimo": (0, 1e12), "minimo_acoes": (1, 100), "janela_dias": (1, 365), "teto_capital_gigante": (0, 1e15),
           "dias_arquivo": (7, 3650), "limite_linhas": (1000, 1000000)}


MAX_EXCLUSOES = 5000


def marca_regras(pasta_base, frente="trabalhista"):
    """Revisão da 0.7.28: (marca, doc, erro) das abas Preferências e Exclusões como estão agora na planilha da frente.
    A tela recebe a marca ao abrir as regras e a devolve ao salvar: se a planilha mudou nesse meio tempo (outra pessoa,
    outro computador, edição à mão) ou não pôde ser lida quando a tela abriu, o salvamento é recusado e nada se perde.
    Sem arquivo: marca "nova". Arquivo que não se lê: marca None e o erro."""
    import hashlib
    import json
    c = caminho(pasta_base, frente)
    if not c or not os.path.exists(c):
        return "nova", None, ""
    try:
        doc = planilha.ler_xlsx(c, so_abas=ABAS_EDITAVEIS)
    except Exception as e:  # noqa: BLE001 - corrompida, em uso, sincronizando: quem chama recusa
        return None, None, e.__class__.__name__
    abas = {cl.sem_acento(a["nome"]).strip().lower(): a["linhas"] for a in doc["abas"]}
    conteudo = json.dumps([abas.get("preferencias", []), abas.get("exclusoes", [])], default=str, ensure_ascii=False)
    return hashlib.sha256(conteudo.encode("utf-8")).hexdigest()[:32], doc, ""


def linhas_regras(valores, exclusoes):
    """0.7.28 (dono): as regras editadas na tela do RADAR viram as linhas das abas Preferências e Exclusões (o escritório
    não precisa mais editar a planilha). Valores fora do limite voltam ao padrão; texto é cortado. Devolve (pref, exc)."""
    nomes = {v: k for k, v in CHAVES.items()}
    pref = [list(LINHAS_PREFERENCIAS[0])]
    for linha in LINHAS_PREFERENCIAS[1:]:
        chave = CHAVES[linha[0]]
        v = (valores or {}).get(chave, PADRAO[chave])
        if chave.startswith(("esconder", "mostrar")):
            v = "sim" if (v is True or _sim(v)) else "não"
        else:
            n = _numero(v, PADRAO[chave])
            mn, mx = LIMITES.get(chave, (0, 1e15))
            try:
                v = n if mn <= float(n) <= mx else PADRAO[chave]
            except (TypeError, ValueError, OverflowError):
                v = PADRAO[chave]
        pref.append([nomes[chave], v, linha[2]])
    exc = [list(LINHAS_EXCLUSOES[0])]
    vistos = set()
    for e in (exclusoes or [])[:MAX_EXCLUSOES]:
        if not isinstance(e, dict):  # revisão da 0.7.28: item que não é {nome, motivo} é ignorado
            continue
        nome = str(e.get("nome") or "").strip()[:160]
        if not nome or nome.lower() in vistos:
            continue
        vistos.add(nome.lower())
        exc.append([nome, str(e.get("motivo") or "").strip()[:200]])
    return pref, exc


def padrao():
    p = dict(PADRAO)
    p.update({"exclusoes": [], "controle": {"ativo": True, "validade": "", "versao_minima": "", "mensagem": "",
                                            "suporte": SUPORTE}, "origem": "padrão", "erro": ""})
    return p


def carregar(pasta_base, doc=None, frente="trabalhista", trocar=None):
    """Lê as abas editáveis da planilha da frente. Sem pasta ou sem arquivo, devolve o padrão; se não conseguir ler,
    diz o erro. `doc` pode ser a planilha já lida (evita ler duas vezes). 0.7.16: as Exclusões das planilhas das outras
    frentes também valem (cliente é cliente em todas). Revisão da 0.7.28: `trocar` ({"Preferências": linhas,
    "Exclusões": linhas}) são as regras que acabaram de ser salvas na tela: valem no lugar dessas abas, e a aba Controle
    e as Exclusões das outras frentes continuam sendo lidas do disco."""
    prefs = padrao()
    c = caminho(pasta_base, frente)
    if doc is None:
        for outra_frente, outro in planilhas_existentes(pasta_base):
            if outra_frente == frente:
                continue
            try:
                outra = planilha.ler_xlsx(outro, so_abas=("Exclusões",))
            except Exception:  # noqa: BLE001 - a outra planilha ilegível não impede esta
                continue
            for a in outra["abas"]:
                if cl.sem_acento(a["nome"]).strip().lower() == "exclusoes":
                    for linha in a["linhas"][1:]:
                        nome = str(linha[0] if linha else "").strip()
                        if nome and not nome.lower().startswith("(exemplo"):
                            prefs["exclusoes"].append({"nome": nome, "motivo": str(linha[1]).strip() if len(linha) > 1 else ""})
        existe = bool(c) and os.path.exists(c)
        if not existe and not trocar:
            return prefs
        try:
            doc = planilha.ler_xlsx(c, so_abas=ABAS_EDITAVEIS) if existe else {"abas": []}
        except Exception as e:  # planilha corrompida ou em uso: o robô segue com o padrão e avisa
            prefs["erro"] = (f"Não consegui ler as abas Preferências e Exclusões de {os.path.basename(c)} (arquivo corrompido ou bloqueado). "
                             "Nesta leitura valem as preferências padrão. / Could not read the Preferences and Exclusions tabs; "
                             f"default preferences apply this time. ({e.__class__.__name__})")
            return prefs
        if trocar:
            doc = {"abas": [a for a in doc["abas"] if cl.sem_acento(a["nome"]).strip().lower() not in ("preferencias", "exclusoes")]
                   + [{"nome": n, "linhas": l} for n, l in trocar.items()]}
    abas = {cl.sem_acento(a["nome"]).strip().lower(): a["linhas"] for a in doc["abas"]}
    for linha in abas.get("preferencias", [])[1:]:
        if len(linha) >= 2 and str(linha[0]).strip() in CHAVES:
            chave = CHAVES[str(linha[0]).strip()]
            prefs[chave] = _sim(linha[1]) if chave.startswith(("esconder", "mostrar")) else _numero(linha[1], PADRAO[chave])
    for linha in abas.get("exclusoes", [])[1:]:
        nome = str(linha[0] if linha else "").strip()
        if nome and not nome.lower().startswith("(exemplo"):
            prefs["exclusoes"].append({"nome": nome, "motivo": str(linha[1]).strip() if len(linha) > 1 else ""})
    for linha in abas.get("controle", [])[1:]:
        chave = cl.sem_acento(str(linha[0] if linha else "")).strip().lower()
        valor = linha[1] if len(linha) > 1 else ""
        if chave == "ativo":
            prefs["controle"]["ativo"] = _sim(valor) if str(valor).strip() else True
        elif chave in ("validade", "versao_minima", "mensagem", "suporte"):
            prefs["controle"][chave] = str(valor if valor is not None else "").strip()
    # integracao@ é só para sistemas (não é lido por pessoas); planilhas antigas que o trazem como suporte passam a judicial@.
    if prefs["controle"].get("suporte", "").strip().lower() in ("", SISTEMAS):
        prefs["controle"]["suporte"] = SUPORTE
    prefs["origem"] = c
    return prefs


def bloqueio(prefs, versao_atual, hoje=None):
    """Motivo para o robô não rodar, ou '' quando pode."""
    c = prefs.get("controle") or {}
    msg = (" " + c["mensagem"]) if c.get("mensagem") else ""
    if not c.get("ativo", True):
        return ("O programa está pausado pela SolverONE (aba Controle)." + msg).strip()
    if c.get("validade"):
        try:
            if (hoje or dt.date.today()) > dt.date.fromisoformat(c["validade"][:10]):
                return (f"A validade terminou em {c['validade'][:10]}." + msg).strip()
        except ValueError:
            pass
    if c.get("versao_minima") and versao_tupla(c["versao_minima"]) > versao_tupla(versao_atual):
        return (f"Precisa atualizar para a versão {c['versao_minima']} ou mais nova (instalada: {versao_atual})." + msg).strip()
    return ""


def aplicar(itens, prefs, acoes_por_empresa=None):
    """Marca item['excluida'] com o motivo (exclusão da planilha ou mínimo de ações). Não remove nada da lista."""
    por_nome = {cl.chave_nome(e["nome"]): e for e in prefs.get("exclusoes") or [] if cl.chave_nome(e["nome"])}
    cnpjs = {re.sub(r"\D", "", e["nome"]) for e in prefs.get("exclusoes") or [] if len(re.sub(r"\D", "", e["nome"])) == 14}
    minimo = int(prefs.get("minimo_acoes") or 1)
    for it in itens:
        motivo = ""
        nomes = it.get("empresas") or []
        cnpj = re.sub(r"\D", "", str((it.get("empresa") or {}).get("cnpj") or ""))
        for n in nomes:
            e = por_nome.get(cl.chave_nome(n))
            if e:
                motivo = "Exclusão: " + (e["motivo"] or e["nome"])
                break
        if not motivo and cnpj and cnpj in cnpjs:
            motivo = "Exclusão: CNPJ na lista"
        if not motivo and minimo > 1 and acoes_por_empresa is not None:
            qtd = max((acoes_por_empresa.get(cl.chave_nome(n), 0) for n in nomes), default=0)
            it["acoes_na_janela"] = qtd
            if qtd < minimo:
                motivo = f"Menos de {minimo} ações em {int(prefs.get('janela_dias') or 30)} dias"
        it["excluida"] = motivo
    return itens
