# LexSuiteONE · RADAR JUDICIAL — robô v0.7.53 (frente trabalhista)

Uma lista por dia: os processos novos contra empresas nos tribunais que você escolher (os 24 TRTs por padrão; também os
TJs, os TRFs, STJ e TST), uma por linha, com a ficha da empresa e do processo. Tudo roda no seu computador, sem
inteligência artificial e sem senha de ninguém. A planilha vai para a sua pasta do Google Drive.

## Instalar (Windows, dois cliques)

O caminho normal é o **instalador de um arquivo**: em judicial.solverone.com.br, "Baixar", abrir o arquivo e dois
cliques em `INSTALAR.bat`. Ele baixa este pacote do site, confere a impressão digital (SHA-256) publicada em
`atualizacao/instalar.txt`, instala em `C:\LexSuiteONE` (ou na pasta do usuário, se o Windows não deixar), prepara o
Python portátil, cria o atalho com o nome do produto na área de trabalho e no menu Iniciar e abre a tela. Rodar de novo
atualiza sem perder configuração nem lista. A fonte é `instalador/INSTALAR.bat` no repositório (não vem no pacote).

À mão, com o pacote completo:

1. Descompacte o `.zip` numa pasta fácil, por exemplo `C:\LexSuiteONE`. A pasta pode ter qualquer nome; mantenha tudo
   junto, porque o robô guarda ali o `config.json`, o banco `lexsuite.db` e a pasta `saida`.
2. Dois cliques em **`ABRIR.bat`**. Na primeira vez ele baixa o Python portátil oficial para dentro da pasta (11 MB,
   sem instalador, sem senha de administrador) e abre a tela no navegador. Uma janela "LexSuiteONE" fica aberta
   enquanto a tela é usada.
3. Na primeira vez a tela (numa janela própria, sem barra de endereço) abre um **passo a passo de boas-vindas** (0.7.10:
   código só para ler, função obrigatória, três opções para a planilha, tribunais escolhidos ali, onde a planilha fica e
   como compartilhar): seu nome e seu papel no escritório (a tela e o
   manual passam a falar com você), o nome do escritório, a **pasta compartilhada** (a tela lista as pastas do Google
   Drive para computador que achou, ou outra pasta pelo "Escolher pasta…"; "Testar pasta" confirma) e a opção **rodar sozinho**
   (de início de segunda a sexta, às 20h e às 8h, já marcada; dias e horários mudam em Configurações). "Começar a primeira rodada" salva tudo, cria a planilha `LexSuiteONE - Trabalhista.xlsx` na pasta escolhida,
   agenda as rodadas e dispara a primeira. Cada campo do passo a passo fica guardado ao sair dele (fechar a tela no meio
   não perde o que foi digitado). Depois, quem usa (nome, e-mail, função, escritório) muda no **perfil** (as iniciais no
   alto da tela, um lápis ✏️ por dado; trocar o e-mail = outra pessoa usando o computador) e o código, a pasta e as
   leituras automáticas, em **Configurações**.
4. **Ler o Diário agora** (até a 0.7.10, "Atualizar agora"): os 24 TRTs já vêm escolhidos (em **Tribunais** dá para mudar: por região, por estado, por
   ramo ou "Selecionar todos"). A primeira rodada baixa o diário do dia de cada tribunal (de 5 a 150 MB cada): os 24
   TRTs levam de 30 a 60 minutos; depois, só o que é novo. O computador precisa estar **no Brasil**.
5. Não é preciso compartilhar nada com a SolverONE (decisão do dono, 09/Nov; até a 0.7.15 o assistente pedia para
   compartilhar a pasta com `integracao@`). Dúvidas de pessoas vão para `judicial@solverone.com.br`.

Tribunais estaduais publicam diários muito maiores (o TJSP sozinho pode passar de 1 GB) e a regra de "ação nova"
ainda não foi calibrada neles.

## A planilha no Drive

Uma por frente (0.7.16), na mesma pasta: `<pasta escolhida>\<subpasta>\LexSuiteONE - Trabalhista.xlsx` (a
`LexSuiteONE.xlsx` antiga vira essa na primeira leitura, com as abas editadas). Ao lado, `Cópias` e `Cópias de segurança`.
A aba Arquivo mostra os últimos 90 dias e todo processo trabalhado; limite de 60 mil linhas por planilha, com aviso a
80% e limpeza com cópia sozinha a 100% (6 cópias guardadas). Configurações → Leitura do Diário → Armazenamento mostra planilhas, banco,
`saida/`, cópias e o espaço livre do disco.

- **Radar** (o robô escreve a cada rodada): a lista do dia, com as mesmas colunas da tela. A partir da 0.7.12, com
  cabeçalho azul-marinho fixo, filtro em todas as colunas, valores em R$ e o valor da causa acima do mínimo em latão
  claro; abre igual no Excel e no Google Planilhas.
- **Como usar**: o passo a passo da planilha, em português e inglês.
- **Critérios desta leitura** (0.7.33, só leitura): com que critérios a pessoa que gravou por último olhou a lista. As
  antigas abas **Preferências** e **Exclusões** saíram: os critérios e as empresas excluídas são de cada pessoa, no
  computador dela, por área (Configurações → Destaques e exclusões); a planilha fica completa, como registro do escritório.
- Abas ocultas, usadas pelo suporte: **Controle** (`ativo`, `validade`, `versao_minima`, `mensagem`, `suporte`),
  **Log** (cada rodada), **Saúde** (o que o robô percebeu: Diário fora do ar, formato mudou, Receita sem resposta) e
  **Sobre** (versão, computador, pasta).

Também fica ali a página `Retrato da última leitura.html` (antes `Lista para abrir no celular.html`), uma foto da lista na última leitura que abre em qualquer lugar. No Google Planilhas,
abra o `.xlsx` para consultar (modo de compatibilidade com Office). Os destaques e as exclusões (empresas excluídas, valor mínimo)
são de cada pessoa, neste computador, por área (0.7.33): Configurações → Destaques e exclusões. A planilha não guarda critérios. Se a planilha estiver aberta e travada na hora de uma rodada, o robô tenta de novo a cada 2 minutos e grava sozinho quando ela for fechada.

## A tela

- **0.7.53 (24/Nov, decisões 59 a 67):** vários computadores na mesma pasta sem computador "mestre" (cada um grava o que fez
  em `_RADAR (não mexer)/troca/<instalação>/`, junta o dos outros ao abrir, antes de gravar a planilha e no botão "Trazer do
  escritório (N)"; trava curta e vetor na aba Sobre para a planilha nunca voltar atrás); "Visto por" e autoria das situações e dos
  contatos; planilha só com os tribunais escolhidos (Radar até 30 dias, Arquivo pela data no Diário) e aba Estatística de todos os
  tribunais lidos, com asterisco de mês parcial no Painel; amostras e assinaturas de formato de todas as fontes, anonimizadas, com
  fila de envio silenciosa (sempre ligada). Módulos novos `amostras.py` e `troca.py`.
- **0.7.52 (24/Nov, teste da 0.7.51 em inglês):** inglês sem sobras de português (avisos do alto, mensagens da leitura,
  setor, porte, tipos de publicação), "Court Journal" no lugar de "gazette", "Manual de uso" / "User guide", termos e condições em
  inglês com seletor PT/EN (o português vale; texto igual, sem aceite novo), limpeza da planilha com andamento, resultado (linhas antes
  e depois) e ✕ no aviso do alto, sem dizer "limpa" se não regravou; consulta ao CNJ mais curta (chave em 2 tentativas, uma por lote,
  para no 429, andamento por lote); Novidades sucintas e janela mais limpa; rodapé do Painel enxuto.
- **0.7.51 (20/Nov, primeiro uso real da KR Law e feedback do teste da 0.7.50):** o processo é novo pela **data de ajuizamento**
  (CNJ/DataJud, lista de distribuição do Diário ou digitada), não pela publicação que o RADAR achou; "novo" = até 30 dias (ajustável em
  Destaques e exclusões, "Dias para o processo ser novo"); o antigo fica na Lista marcado "PROCESSO ANTIGO". Cada leitura completa os
  processos com o CNJ (em lotes de 40, com fila em disco na tabela `fontes`, nova tentativa em 30 min/2 h/6 h/24 h e "Tentar de novo"
  na ficha) e com o histórico do Diário pelo número (só datas e tipos; texto e destinatários descartados). Ficha com a jornada do
  processo (recolhida; duas colunas com a linha em degrau), etiquetas de fonte com (?), 1ª e última publicação, andamento; filtros
  Idade do processo e Andamento; ordem padrão pelos ajuizados mais novos; cumprimento de sentença fora. Planilha: "Ajuizado em" (só a
  data real) e colunas novas no fim. Também: período de cada leitura (desde a última leitura, últimos 7 dias, último dia útil) na faixa
  e na Rotina de leitura, aviso de leitura longa e "Salvar e ler agora"; Novidades toda vez até "Não mostrar novamente" e página
  "Histórico de versões" no site; número do processo no formato CNJ no cartão e ícones de copiar; "CNPJ não capturado"; carregando
  numa faixa sobre a Lista; ficha montada só ao abrir; registro com "Abrir no Gmail" e "Abrir no e-mail do Windows"; AssistONE em
  tópicos; ressalvas da Operação (exclusão pelo CNPJ, CNPJ provável pelo nome exato, pré-filtro com acento).
- **0.7.50 (16/Nov, feedback do dono no notebook e no agrupamento):** no agrupamento por empresa, o alcance vale para o bloco
  inteiro; setinha para recolher e abrir (recolhido com mais de 10 empresas ou 10 processos), "Expandir todas" e "Recolher todas";
  caixinha da empresa marca todos os processos dela; empresa sem CNPJ com triângulo de aviso e "CNPJ provável" (uma raiz só para o
  mesmo nome; com confirmação, grava `cnpj_inferido`); "Copiar o contato para os sem contato" (30 a 365 dias, padrão 90; só o
  contato da empresa, marcado "copiado", com desfazer) e "Excluir esta empresa". Filtros numa linha no notebook (seletores do tamanho
  do texto, rótulos curtos com a dica dos marcados, dois degraus de encurtar) e barra compacta ao rolar. Barra de seleção com
  "Aplicar" e "Arquivar" sem número; aviso de Desfazer claro, acima da barra. Configurações: rodapé largo com linha azul, frase
  "As alterações desta janela passam a valer depois de Salvar.", consulta pública com (?), Rotina de limpeza própria (vermelho para
  confirmar, "Não confirmar", prazos gravados ao limpar), volta do Histórico no mesmo ponto com deslize, registro técnico com copiar e
  "Enviar ao suporte" (licença só com os 4 últimos, sem a pasta do usuário). "Banco" virou "dados do programa" nos textos. Conexão
  fechada pela tela (WinError 10053) não deixa rastro no registro. Tour do AssistONE trava a rolagem.
- **0.7.49 (15/Nov, decisões 43 a 48):** "Modo: Trabalhista" no alto (as outras especialidades apagadas, "Não incluído na sua
  licença"), no lugar de "Abrir a planilha", que fica no menu ☰ → Planilha ("planilha oficial, só leitura"); filtros salvos numa
  lista própria (larga, abre para a esquerda, nome e descrição; guardam período e agrupamento) e 3 de fábrica, uma vez por
  computador, com os tribunais do primeiro acesso (lendo mais de 4, TRT2 e TRT15); Tribunal na 1ª linha dos filtros, sempre à vista;
  listas de filtro com a largura do nome mais comprido e que acompanham o botão ao rolar; Varas com "Nº" antes do nome; (?) na cor de
  link, que volta ao cinza aberto, com balão que cresce; **Agrupar por empresa** (bloco por empresa, empresas pela data mais recente,
  processos anteriores da empresa mesmo fora do período, alcance padrão "até 50 dos últimos 6 meses", `radar.processos_das_empresas`
  e rota `/empresas/processos`, mesma empresa pela raiz do CNPJ; a chave é o CNPJ (dono): homônimo de outro CNPJ fora, processo sem CNPJ com o mesmo nome marcado "confira" e fora do total; sem CNPJ nenhum, pelo nome); Wizard explica filtros e limpeza.
- **0.7.48 (15/Nov, protótipo aprovado pelo dono):** (1) **leitura pela consulta pública** quando o caderno do CNJ cai (desenho 1.3,
  decisão 37): só nos dias com 5xx, com a sonda da consulta respondendo e o observador da SolverONE sem a consulta fora;
  `djen.consulta_dia` (itensPorPagina 100, passa a 50 se recusado; 1 pedido/s; 15 s; 1 nova tentativa em tempo esgotado e 5xx;
  para em 3 tempos esgotados seguidos; `count` ≥ 10.000 vai vara por vara, com as varas guardadas dos cadernos já lidos, tabela
  `varas`); uma vez por dia pendente (`consultas_dia`); o dia continua pendente e, quando o caderno volta, a leitura confere,
  passa a fonte a "caderno" e conta os "a mais" (sem duplicar); quatro cenas na faixa, "Ver os N processos" (filtro "Novos desta
  leitura"), selo "consulta pública · caderno pendente", linhas no Histórico; ligada por padrão, `radar.consulta_publica`
  (Configurações → Leitura do Diário). (2) **Limpeza automática do banco** (decisões 40 a 42): depois de cada leitura, resume com
  6 meses e apaga com 24 os não trabalhados (`radar.resumir_meses`, `radar.apagar_meses`; 0 = nunca); trabalhado = situação
  diferente de Novo e Visto, contato, dado digitado ou área logada; memória `processos_apagados` (12 meses); VACUUM quando vale;
  registro "limpeza" no Histórico; em Armazenamento, prazos, "O que nunca sai", última limpeza e "Limpar o banco agora" (dois
  cliques, em segundo plano). (3) **Filtro de cidade** logo depois do Estado (Lista e Painel; sem acento, mais processos primeiro,
  "Sem cidade", 200 opções e busca; trocar o estado tira a cidade de fora, com aviso; o Estado conta sem a cidade). (4) **Área
  logada** (14 itens do teste do dono): círculos clicáveis com nome, pedido montado só com os escolhidos (`radar.itens_de`), ícone de
  copiar, (?) do .md, regra do CPF só no (?) do passo 1, "Colar a resposta agora"/"Fechar (trago a resposta depois)", área de
  arrastar, sócio marcado, (?) dentro da janela, "Quantos" com o limite, mensagem sem jargão. (5) **Janelas** arrastáveis pelo
  título e com tamanho pelo canto; ao reabrir, centro e tamanho padrão. (6) Faixa vermelha com o texto na largura toda e as
  ações embaixo, como link; "Tudo certo" do Armazenamento; e-mail do aviso do CNJ com o endereço (sem cadastro, desligado).
- **0.7.47 (14/Nov, CNJ fora e antivírus, desenho da Arquitetura):** quando o CNJ falha, o programa diz se é do CNJ ou deste
  computador (duas sondas leves de controle; frase na faixa, no Histórico e em "Detalhes técnicos") e, quando a SolverONE também
  vê o CNJ fora, mostra isso; opção de aviso por e-mail quando o CNJ ficar fora por mais de 4 horas em dia útil (desligada).
  Configurações → Sobre este computador mostra o antivírus e o firewall, com o link dos passos para liberar; as mensagens de
  bloqueio nomeiam o antivírus. O instalador confere o computador antes de baixar, orienta em cada bloqueio (nunca manda
  desligar o antivírus) e cria a leitura automática na própria janela; o XML da tarefa fica em `C:\LexSuiteONE\tarefa.xml`.
- **0.7.46 (14/Nov, Área logada v2, desenho da Arquitetura):** "Trazer dados da área logada…" em quatro passos numa janela
  que não trava o programa: (1) o que pedir (marcados, primeiros N da lista filtrada ou os próximos que ainda não foram ao PJe;
  quais dados), com contagem, lotes e tempo estimado; limite POR PEDIDO (padrão 25, máximo 50, `radar.area_logada_por_pedido`,
  Configurações → Área logada), em lotes de 25; (2) o pedido numa caixa com "Copiar de novo" (0.7.48: ícone de copiar) e "Salvar como arquivo", roteiro do
  PJe dos TRTs (mapa pjekz) ou genérico para os outros tribunais, um bloco de resposta por lote; "Fechar e voltar" deixa a faixa
  "pedido aguardando resposta" (gravada no banco: `area_pedidos`); (3) colar ou subir .md/.txt/.zip (até 20 MB, `zipfile`, só
  leitura): `contatos.ler_resposta` acha todos os blocos v1 em qualquer ordem, lê as colunas pelo nome do cabeçalho, conta linha
  repetida uma vez e recusa o resto com o motivo; sem bloco, "Não achei a tabela…" (0.7.48: "Não encontrei a resposta da ferramenta neste texto…") + 3 primeiras linhas; (4) o que mudou:
  `banco.completar_fonte` nunca apaga e só troca por fonte mais forte (PJe dados do processo > petição > citação > Diário >
  Receita > digitado) ou igual e mais nova, com o anterior em `manual_historico`; contato novo entra junto. Memória por processo
  e dado (`area_logada`), filtro "Área logada" (depois da 1ª resposta), selo "área logada · data", menu ☰ → Área logada com
  "Gerar pedido…" e "Trazer resposta…", interruptor por licença `data-recurso="area-logada"` (barra, cartão, menu, filtro,
  faixa; até a nuvem mandar, ligado). Defeitos da 0.7.45: (?) da barra de lote fixo e dentro da tela, janela do pedido uma só
  e com o texto, "7 colunas", sem abrir a pasta.
- **0.7.45 (13/Nov):** com a tela aberta, se a hora marcada passa (folga de 10 minutos, até 12 horas) sem leitura, o
  programa lê sozinho, uma vez por horário (`app.conferir_agenda`, thread `vigiar-agenda`; vale com "Ler sozinho" ligado,
  guardado em `radar.agendar_quer`, ou com a tarefa do Windows existente): resposta ao antivírus que impede a tarefa (KR Law).
  "Trazer dados da área logada" com o prompt v2 do PJe (Arquitetura, mapa real do TRT2): roteiro só de leitura no pedido,
  processos agrupados por tribunal, fonte "PJe dados do processo" (confiança alta, primeiro na ficha), endereço "a
  conferir" da petição marcado (confiança baixa), texto da janela com 7 colunas.
- **0.7.44 (13/Nov):** com a tela aberta, o programa confere o CNJ um minuto depois de abrir e de 15 em 15 minutos,
  só quando falta ler algum Diário (`cadernos_pendentes`, da 0.7.42) ou a última leitura parou com o CNJ fora: um pedido,
  uma tentativa (`app.conferir_cnj`, thread `vigiar-cnj`). A faixa vermelha do Painel diz até que dia o tribunal já foi lido
  ("Nada se perdeu") e a última conferência; quando o CNJ volta, aviso verde e, com a leitura automática ligada, a leitura
  dos Diários que faltaram começa sozinha. Falha ao criar a leitura automática orienta sobre o antivírus (Bitdefender).
- **0.7.43 (13/Nov):** empresas excluídas pelo nome valem só para o nome escrito igual (`classificar.chave_exata`: sem acento,
  caixa e pontuação, sem tirar LTDA/S.A./ME/CIA); o CPF exclui o MEI ou empresário individual cujo nome traz esse CPF
  (`classificar.cpfs_no_nome`), sem buscar nome; o CNPJ continua exato; (?) na frase das excluídas e aviso ao digitar um CPF.
  Painel e Lista mais rápidos com muitos processos (o Painel não ordena; valores digitados lidos uma vez; cada processo
  avaliado uma vez por desenho): com 40 mil, abrir o Painel de 1,2 s para 0,5 s. AssistONE diz "Aguarde o RADAR JUDICIAL
  carregar" enquanto a tela de carregamento está aberta.
  Configurações: reabertas logo depois de salvar, mostravam o que era antes (a carga antiga da lista chegava depois e
  voltava a configuração; o disco estava certo): só a carga mais nova vale e a tela fica com o que foi salvo; o Salvar gira
  enquanto grava e só manda a pasta e o agendamento do Windows quando mudaram. Busca da Lista sem travar a digitação (começa
  com 2 letras, espera a pausa; o texto de busca de cada processo é preparado uma vez). Teste de regressão de tela
  `testes/tela/fluxos.js` e `testes/tela/rodar_tudo.sh` (todos os testes de uma vez, antes de cada "pronta para revisão").
- **0.7.42 (dono, 13/Nov, com o CNJ fora):** Diário que o CNJ não entrega (erro 5xx) não interrompe mais a leitura: o dia
  é pulado, a leitura volta mais dias (até 10 dias úteis) e o dia fica anotado (tabela `cadernos_pendentes`) e é lido sozinho
  nas próximas leituras, mesmo fora do período escolhido. Três Diários seguidos com erro: o CNJ está fora; a leitura não
  insiste e os outros pedidos tentam menos vezes. Mensagem na tela: os Diários que faltaram entram na próxima leitura.
- **0.7.41 (instalação na KR Law, 13/Nov, correção urgente):** o CNJ passou a responder "Server Error" (500) para o caderno
  do dia que ainda está sendo montado, e a leitura inteira parava ("Site do CNJ fora do ar") sem ler os dias anteriores. Agora o
  dia de hoje com esse erro conta como "ainda não publicado": a leitura pula hoje e lê até o dia anterior. Erro em dia
  anterior continua sendo falha do tribunal.
- **0.7.40 (teste do dono na 0.7.39, 13/Nov):** interruptor **"Último mês"** à direita das abas, ligado por padrão: a
  Lista, os números, os cartões, os filtros e a busca carregam só os últimos 30 dias (`/dados?max=30` na 1ª carga);
  Processos por dia usa os totais guardados dos 90 dias (`totais_dia`) e a Sazonalidade continua completa; 60 e 90 dias
  desligam o interruptor com aviso. Riscar empresa, faixa ou "Outros" redesenha só o cartão; as trocas pesadas mostram
  "Volume grande de processos, aguarde…". Filtro **Tipo de publicação** (antes "Como o processo novo foi reconhecido"),
  rótulos com a mesma caixa e "Não registrado (leitura antiga)". "Ver na lista" das Empresas leva as empresas mostradas
  (filtro "N empresas ✕"); 5/10/15 manda e fica embaixo do anel; nas barras, "Outros (N)" para o total bater com a Lista.
  Busca da Lista: a empresa procurada em destaque em "Também no processo" e primeiro onde é a empresa principal. Nomes sem
  aspas soltas (robô e tela). Balões (?) com o dobro da largura; etiqueta das barras em linhas, com plural. "A mira do
  escritório" curta, com atalhos. Próxima leitura automática na linha dos tribunais; no celular, os dois botões lado a lado.
  Imagens de fundo sorteadas (4, dentro da página) nas telas de abertura, atualização, reinício e Sair. Pacote completo de
  instalação (`instalador/INSTALAR-COMPLETO.bat`, montado por `ferramentas/marca.py`) para antivírus ou rede restrita.
- **0.7.39 (teste do dono na 0.7.38, 13/Nov):** barra do dia de hoje (Processos por dia) e do mês corrente (Sazonalidade)
  com contorno tracejado, pela data de Brasília, até a meia-noite (o Diário do dia ainda recebe processos até a noite), com
  legenda e etiqueta "dia em andamento"; título "Estatísticas" com (?) acima dos oito cartões; "Limpar filtros (N)" conta e
  desfaz também o que se risca nas pizzas que não são filtro (Faixas, Empresas, Como foi reconhecido); "Ver na lista" em
  Faixas de valor (leva "Acima de…" ou "Sem valor" quando dá) e em Empresas (leva a empresa quando só uma ficou ligada);
  Empresas com 5, 10 ou 15 primeiras; empresas excluídas com motivo longo sem alargar a janela, "Remover", ▸ para o motivo
  inteiro e ✎ para editar o motivo; faixa "Configuração da leitura" numa altura só no computador (de 106 para 59 px).
  As imagens de fundo das telas de carregamento ficam para quando o dono mandar os 4 arquivos.
- **0.7.38 (13/Nov):** o aviso "não couberam" ao copiar empresas excluídas para outra área sai em dourado (decisão do
  dono, pergunta 19); a confirmação "✓ Acrescentada" fica até a próxima digitação (antes sumia ao sair do campo).
- **0.7.37 (teste do dono na 0.7.36, 13/Nov):** no Painel, Situação (no alto) e Vara, Setor, Porte e Estado (dentro de
  "Mais filtros") aparecem mesmo sem estar ligados: o que sai de um gráfico aparece no filtro correspondente, em vez de surgir do nada;
  Configurações sem o parágrafo de abertura e mais larga (1280 px); busca das empresas excluídas sem rótulo repetido; na
  faixa da leitura, sem a frase que anunciava o caminho do arquivo e, no celular, barra e Interromper fixos na primeira
  linha; "1 processo novo" e "1 notice read" também no inglês e na aba Saúde; o nome pelo CNPJ só diz "não encontrado"
  quando todas as fontes responderam; duplo clique em Acrescentar sem erro falso; "processos" no e-mail de aviso e nas
  mensagens da linha de comando.
- **0.7.36 (teste do dono na 0.7.35, 12/Nov):** Configurações em quatro seções com faixa (Processos, Leitura do Diário,
  Tela, Licença e termos); "Critérios da lista" vira "Destaques e exclusões" e "Leitura automática" vira "Rotina de
  leitura"; "processos" no lugar de "ações" nas telas; Licença e termos com o código, a situação ("ativa" em verde) e a
  validade numa linha, "Conferir agora" que mostra que está conferindo, termos numa linha e Sobre este computador sem
  repetir a licença ("Último envio", (?) na chave de atualização); verificar atualização em verde, azul ou vermelho;
  Pasta das planilhas com o caminho uma vez só, botões numa linha (Escolher pasta, Google Drive, OneDrive sem nome
  entre parênteses) e "Abrir a pasta no Windows" separado; empresas excluídas com o nome pelo CNPJ (cadastro público),
  busca separada que não esconde em silêncio, motivo de cada recusa e uma linha por empresa; copiar para outras áreas
  só com mais de uma área em uso, escolhendo áreas, partes e se soma ou substitui; barras de Processos por dia
  separadas por tribunal, situação, faixa de valor ou setor (Sazonalidade por tribunal), sem o dourado; pizza que se
  refaz com movimento e itens todos clicáveis; dicas (?) em blocos; Buscar estatísticas responde na hora; faixa da
  leitura numa linha, sem caminho de arquivo; "Nada novo" quando a leitura não traz publicação nova; Histórico de
  leituras fora das abas (Configurações → Sobre este computador, e faixa vermelha no Painel quando uma leitura falha);
  lupa vazia só orienta, acha pelo começo das palavras, sem repetidos e com Sair; ressalvas da Operação (Conferir agora
  durante a leitura, Trocar licença encadeado, avisos sem empilhar, texto em EN). Nas revisões da Operação: nome da empresa
  pelo CNPJ com o cache do banco, uma tentativa curta e limite de 10 s na tela ("sem internet ou fonte ocupada" separado de
  "não encontrado"); erro sempre em vermelho e botão desabilitado em cinza; avisos de abrir planilha ou pasta sem "A leitura
  parou"; textos do servidor e da planilha com "processos" e "Destaques e exclusões"; código que roda também no Python 3.11.
- **0.7.35 (dono, 12/Nov):** tela de abertura enquanto carrega; "Conferir agora" em Licença e termos; "Abrir a pasta no
  Windows" em Pasta das planilhas; "Continuar à noite" também com a busca parada; faixa da leitura numa linha (mensagens
  anteriores recolhidas); Novidades largas no computador; ao encerrar, a janela tenta se fechar e diz como abrir de novo.
- **0.7.34 (dono, 12/Nov):** depois do aceite dos termos na página, o programa confere sozinho com a SolverONE ao voltar
  para a janela (e a cada 15 s por até 10 minutos depois de abrir a página), e "Ler o Diário agora" confere antes de mostrar o
  aviso; o aviso ganhou "Já aceitei". O banco espera até 30 s pela vez em vez de cair com "database is locked".
- **0.7.33 (dono, 12/Nov):** critérios da lista e empresas excluídas de cada pessoa, neste computador, por área
  (`criterios.json`; migração única das abas da planilha; "Copiar estes critérios para as outras áreas"; valor vazio = sem
  mínimo; números com ponto; CPF e CNPJ conferidos, inclusive o CNPJ com letras; um Salvar só); CNPJ com letras reconhecido
  nos Diários e na ficha; Painel sem
  busca e sem filtros repetidos, com etiqueta grande nos gráficos; sazonalidade lendo a fila inteira com barra por mês,
  Pausar e Continuar à noite; menu Configurações com os nomes da janela e grupo Ajuda; planilha completa com a aba
  "Critérios desta leitura". Pacote com 46/45 arquivos (novo `lexsuite/documento.py`).
- **0.7.32 (dono, 11/Nov):** gráficos do Painel com dica ao passar o mouse, item ligado e desligado pela legenda
  (apagado, "Mostrar todos"), "Ver na lista →" e cor escolhida ("Cores originais"); filtros do Painel separados dos da
  Lista; leitura automática por dias da semana (padrão de segunda a sexta; nenhum dia = desligada); Configuração
  reorganizada (A lista, Onde ficam as planilhas, Leitura, Tela, Licença e termos com "Trocar licença"), menu
  "Configurações" na mesma ordem, Aparência também na Configuração; ressalvas da revisão da 0.7.31.
- **0.7.31 (teste do dono na 0.7.30, 11/Nov):** termos e licença com textos curtos (sem o link por extenso nem o código),
  código travado e mascarado, Termos com um botão; Sazonalidade com um botão e "Últimos N meses"; "Publicado no Diário";
  Configuração da leitura mais baixa; setas que giram e painéis que abrem e fecham com movimento; Configuração e Perfil
  em janela e rolando com a roda do mouse; (?) na frente; desligar a leitura automática com confirmação e aviso na tela
  inicial; manual genérico, com o ícone embutido.
- **0.7.30, revisão da Operação (11/Nov):** menu ☰ legível no modo escuro; no celular, "Mais filtros" aberto não
  alarga a página; "último dia útil" pula feriado nacional; Esc fecha o Perfil; impressão sempre no claro; contraste
  mínimo em todo texto (claro e escuro), conferido pelo `larguras.js`.
- **0.7.30 (teste do dono, 11/Nov):** tela em três blocos: "Configuração da leitura" numa faixa baixa (o que o programa
  lê, "Alterar configuração", "Ler o Diário agora", que salva e lê os tribunais marcados), "Filtros" numa linha só no
  computador, fixos no alto ao rolar (busca, Data do processo, Situação, Valor, "Mais filtros" com todos os outros,
  filtros salvos sempre à vista com "★ Salvar", ✕ em cada filtro ligado, "Marcar todos", "Limpar filtros (N)" em
  pílula vermelha) e a ordenação com "Baixar a lista (.csv)" em dourado. **Data do processo** conta pela data no
  Diário (1 = do último dia útil até hoje; até 90 dias); o filtro de tribunais mostra só o que está na lista; a
  Configuração diz os tribunais lidos com atalho para a mira. Painel: faixa com de quando são os números e o período
  (troca na hora quando já carregado, com círculo girando quando carrega), tribunal à vista, "Separar por tribunal"
  nas barras por dia (lembrado), "Ver como: Barras | Pizza", meses com letras, "Buscar estatísticas" responde ali.
  Abas com destaque e barrinha deslizando; modo escuro sóbrio no Perfil (Claro, Escuro, Igual ao sistema); "Licença:
  ✓ ativa" com cor por estado; sem licença ativa, "Ler o Diário agora" explica e leva aos termos; a faixa de versão
  nova aparece também com a tela aberta (confere a cada 30 minutos); com janela aberta a página de trás não rola;
  janela fechada no X e novo clique no atalho reabrem a tela. Ressalvas da segunda revisão da 0.7.29 feitas.
- **0.7.29 (dono): sem janela preta.** A tela e a leitura automática rodam sem janela de prompt de comando
  (`pythonw.exe` do Python portátil): o atalho abre o programa direto, a tarefa do Windows é recriada sozinha para chamar
  o Python sem janela, e o que aparecia na janela preta fica em `saida/registro.txt` (Configuração → **Ver registro**).
  Erro antes de a tela abrir: caixa de aviso do Windows; leitura que para com erro: aviso no canto da tela. Sair: ☰ →
  Sair, ou sozinho 3 minutos depois de fechar a tela; se travar: `DIAGNOSTICO.bat`, opção 2. Suporte: `ABRIR.bat --ver`.
  Também: "Salvar regras" recusado durante uma leitura (ela regravaria as regras antigas), "Salvar" da Configuração
  pergunta pelas regras não salvas, Esc com mudança pergunta, nome digitado entra junto ao salvar, cópias "antes de
  salvar regras" no mesmo segundo não se sobrescrevem, números inteiros onde só cabe inteiro, Saúde sem falso alarme
  quando os Diários já tinham sido conferidos, mês em inglês no histórico em inglês, manual sem "edite a planilha à mão".
  Teste do dono (11/Nov): sem "Ver a lista" e "Abrir a planilha" debaixo da última leitura (a lista está logo abaixo e
  a planilha tem o botão no alto); o painel da mira mostra as 4 fases do RADAR, com a 1ª em destaque.
- **0.7.28 (teste do dono no Windows):** datas com o mês em letras em todo o programa (10/NOV/2026) e fuso ao lado
  da hora, como "(Brasília)"; critério do "Ler o Diário agora" curto, com o atalho "alterar"; filtros em azul-marinho e
  ordenação em dourado, com "Limpar filtros" sempre ao lado (apagado quando não há filtro); a lista lembra os últimos
  filtros; toda janela tem ✕, Cancelar e fecha ao clicar fora; filtros salvos em ordem alfabética, com renomear,
  arquivar e apagar nas Configurações (ficam neste computador por enquanto); **Regras do escritório** (desde a 0.7.32, **Critérios da lista**; desde a 0.7.36, **Destaques e exclusões**) nas Configurações
  (valor mínimo, jurídico próprio, sócios, arquivo, limite e empresas excluídas) editadas na tela e gravadas pelo RADAR
  nas abas Preferências e Exclusões da planilha (sem editar Excel à mão; entram na cópia de segurança); clicar de novo
  no atalho com a tela aberta não abre outra janela: a tela aberta avisa "O RADAR já estava aberto aqui".
- **0.7.28:** ressalvas da revisão da 0.7.27: limite de área logada por dia e meses guardados com `Infinity`, `NaN` ou
  texto no `config.json` não derrubam a tela; a lupa do retrato salvo mostra o exemplo certo; o servidor de teste com
  dados fictícios não sai para a internet em nenhuma rota.
- **0.7.27:** ressalvas da revisão da 0.7.26: `Infinity`/`NaN` escritos à mão em valor mínimo, dias na página e teto de
  capital não impedem mais a tela de abrir; o aviso de planilha em uso não se repete e diz a verdade também sem Excel;
  a lupa do retrato salvo oferece só Painel e Lista; o servidor de teste com dados fictícios não faz a leitura do Diário.
- **0.7.26:** ressalvas da revisão da 0.7.25: `dias_na_pagina` absurdo no `config.json` não impede mais gravar a página e a
  planilha no fim da leitura; o aviso de planilha em uso diz a verdade (pode ser Excel aberto ou falta de permissão) e
  fica na tela até a próxima ação; a lupa do retrato salvo só oferece o que funciona offline; testes que de fato falham
  se as correções forem desfeitas.
- **0.7.25:** ressalvas das revisões da 0.7.23 e da 0.7.24: "Abrir a planilha" não marca "somente leitura" se ela
  estiver aberta para edição em outro lugar (e avisa); valores absurdos no config ou nos pedidos não derrubam a tela;
  título da janela de pastas sem "Meu Drive"; lupa sem as partes da Configuração no retrato salvo e sem repetir itens;
  fechar a lupa pelo ✕ devolve o foco; o alvo da Configuração não some sob o cabeçalho; teste contra comentário que
  engole código mais rigoroso.
- **0.7.24 (teste do dono no Windows da 0.7.23):** o link "Abrir a planilha" da última leitura também mostra o aviso de
  "só para leitura"; a planilha de consulta fica marcada "somente leitura" já ao abrir; a lupa acha as partes da
  Configuração ("Onde ficam as planilhas", horários, armazenamento, termos, AssistONE); o critério de "Ler o Diário
  agora" fica embaixo do botão; as opções de pasta chamam "Pasta padrão do RADAR" e "Outra pasta".
- **0.7.23:** ressalvas da revisão da 0.7.22: textos sem "Google Drive" como padrão, aviso de planilha que fala também
  de falta de permissão, passo do tour com "Área logada", motivos da licença em inglês na tela em EN, números do
  `config.json` com limite (texto ou valor absurdo não derrubam a tela nem a leitura), nome do escritório sempre válido
  na cópia de trabalho e testes que faltavam.
- **0.7.22:** AssistONE 1.1.1 (master do RootifyONE): no tour, o balão desliza de um passo ao outro, o personagem não
  some (só se cobrir o que está sendo mostrado) e o "Próximo ›" cabe numa linha.
- **0.7.21 (teste do dono no Windows):** pastas em duas opções (Neste computador, padrão, ou Pasta compartilhada:
  rede, OneDrive ou Google Drive para computador, com atalho quando estão instalados) e explicação antes de mudar;
  planilha de consulta marcada "somente leitura" no Windows (abre só para leitura até com dois cliques; "Editar
  Preferências e Exclusões" tira a marca); aviso "planilha só para leitura" volta a cada versão, licença ou pessoa nova;
  (?) ao lado de "Abrir a planilha"; cópia de trabalho com o nome do escritório; embaixo de "Ler o Diário agora", o que
  ele vai ler; validade da licença ("válida até …" ou "sem data de vencimento"); menu "Área logada → Trazer dados da
  área logada". Também as ressalvas da revisão da 0.7.20: regra de segurança da página também para formulários e molduras; erro das
  estatísticas antigas aparece na hora e só diz "a SolverONE foi avisada" depois de o aviso chegar; "última leitura"
  também com o programa em pasta de rede; AssistONE diz o que vai à SolverONE (Configuração e Primeiro acesso) e o
  "Próximo ›" do tour cabe numa linha.
- **0.7.20:** a SolverONE pode desligar o AssistONE pelo RootifyONE (Controle dos apps): o aviso chega na conferência
  da licença, sem a tela fazer pedido à internet; desligado assim, o cartão da Configuração diz "Desligado pela
  administração da SolverONE". O link "Aceitar em nome do escritório" leva código, e-mail e nome depois do `#`, que não
  vai ao servidor nem fica em registro dele.
- **0.7.19:** menu ☰ em gaveta que desliza, com cabeçalhos de grupo (não clicáveis), itens recuados com seta e "Sair"
  separado em vermelho; **lupa** ao lado da engrenagem, que procura empresa, processo, CNPJ, cidade, opção do programa
  e assunto do manual; engrenagem centrada; "Interromper" virou botão vermelho; depois de reiniciar, a tela mostra a
  última leitura guardada (não "Ainda não leu"); Configuração → pasta com três opções explicadas (Google Drive,
  só neste computador, outra pasta), o caminho inteiro e o teste automático (sem botão "Testar"); a janela de pastas
  do Windows abre na frente; termos com um link só para ler e, se faltar, "Aceitar em nome do escritório" já com
  código, nome e e-mail; código de cliente mascarado no perfil e na Configuração; motivo da parada das estatísticas
  fica na tela, em PT ou EN; gráfico "Como a ação nova foi reconhecida". Antes de mudar o banco, a atualização guarda
  uma cópia `lexsuite.db.antes-<versão>-<data>` na pasta do programa (fica só neste computador; o
  `PREPARAR-PARA-CLIENTE.bat` a apaga). **AssistONE**, o assistente de todos os apps da SolverONE, no canto inferior
  direito: explica a tela onde a pessoa está, faz um tour rápido, dá uma dica por tela e procura funções; liga e
  desliga em Configuração → AssistONE. Sem IA e sem internet (só ajuda; as escolhas ficam neste navegador).
- **0.7.18:** **estatísticas dos meses anteriores** no Painel ("Sazonalidade": ações novas por mês e por dia da
  semana, mês de pico): o escritório escolhe quantos meses (padrão 3), o RADAR lê os Diários antigos (desde a 0.7.33, a fila inteira, com pausa, barra por mês, Pausar e Continuar à
  noite), e guarda os totais e, só neste computador, o número dos processos já contados; engrenagem ⚙ ao lado do perfil (abre a
  Configuração numa janela por cima); perfil na mesma janela, com a licença do escritório, e-mail e escritório fixos
  e "Outra pessoa vai usar este computador"; pelo menu ☰, Configuração e perfil abrem como página com "Voltar";
  "Gerar uma cópia" com "Abrir a cópia" e "Abrir a pasta"; o estado (UF) da empresa vem do endereço trazido da área
  logada; limpeza única do que a regra antiga guardou e não é ação nova (fica no banco, fora da lista).
- **0.7.17:** filtros com várias opções (caixas de marcar), contagem de cada opção que segue os outros filtros (o que
  daria zero some), "Limpar filtros" sempre que houver filtro ligado; turmas e gabinetes (2º grau) fora da lista; banco
  acima de 1 GB resume com 6 meses só os processos nunca abertos; limpeza automática só com cópia; data da mudança do
  critério de "ação nova" no Painel.
- **0.7.16:** regra de "ação nova" mais estreita (antes, "fica notificado" e "citação" de qualquer processo do ano
  entravam: dois TRTs davam 20 mil "novos"); uma planilha por frente; cópias de segurança e armazenamento; leitura só
  das abas editáveis (a planilha grande dava "ValueError"); Configuração em janela própria com ✕ e Salvar; "Buscar na
  área logada" com a resposta padronizada `RESPOSTA PARA O RADAR v1` (qualquer extensão de IA); valor da causa e data
  de ajuizamento guardados no programa; ✓ ao salvar; "Sair do RADAR" e encerramento sozinho 3 minutos depois de fechar a tela (desde a 0.7.29 sem janela preta)
  da tela; carregamento ao atualizar; termos das duas camadas na Configuração; nada é compartilhado com a SolverONE.
- **0.7.15:** botão **Interromper** durante a leitura (para num ponto seguro; as ações já gravadas ficam) e aviso de
  "leitura das 08h00 feita agora" quando o computador estava desligado na hora marcada.
- **0.7.14:** menu ☰ (Configuração, planilha, contatos), abas Painel · Lista · Arquivo · Histórico de leituras, um
  processo por linha com a **situação** (Novo, Visto, Em análise, Em contato, Virou cliente, Descartado, Arquivado) e o
  selo de contato, seleção de vários com "Desfazer", busca, filtros novos e filtros salvos. A planilha abre só para
  leitura; "Gerar uma cópia" cria uma cópia para trabalhar.

- **Leitura entre meia-noite e 3h (0.7.13):** o Diário do dia só sai às 3h; o programa avisa e lê até o último dia
  publicado. Se o site do CNJ estiver fora do ar, a tela diz isso (não é problema do computador) e lê os outros
  tribunais. **Histórico de leituras** (abaixo do estado) e a aba **Log** da planilha mostram cada tentativa.

- **Painel e Lista (0.7.12):** o Painel mostra os números do período (ações, acima do valor mínimo, valor somado, com
  CNPJ, empresas, sem valor), ações por dia, faixas de valor, setores, empresas com mais ações, porte, tribunais e
  estados. Os filtros valem para os dois; clicar numa barra abre a Lista já filtrada. A tela lembra a última aba.
- **Uma linha por ação:** tribunal, empresa, setor, porte, cidade, vara e o valor da causa (ou "a conferir").
- **Clique na linha, a ficha abre:** cada dado numa linha própria, sempre presente; o que falta aparece como
  "não informado no cadastro" (a Receita não tem) ou "não capturado" (está no PJe, atrás do captcha).
- **Filtros:** acima do valor mínimo; sem jurídico próprio provável; mostrar excluídas; um tribunal ou todos.
  **Período:** último dia, 3, 7, 15 ou 30 dias. **Exportar planilha** gera um `.csv` com o que está na tela.
- **Valor da causa:** o Diário não traz; está na consulta pública do PJe atrás de um captcha. Botão "Abrir consulta no
  PJe", "Copiar número", e o campo para digitar o valor (fica no navegador e sai na planilha exportada).
- **Configuração:** seu nome e papel, escritório, pasta compartilhada, rodar sozinho, versão instalada, chave de
  atualização e o botão "Verificar atualização". **Manual do escritório** no rodapé, personalizado para o seu papel.

## Rodar sozinho

- A opção "Ler sozinho" da Configuração cria a tarefa "LexSuiteONE Radar" no Agendador do Windows, com os horários
  escolhidos (padrão 20h e 8h, até 6, nos dias da semana marcados, de início de segunda a sexta; se o computador estava desligado, roda quando
  ele ligar). Ela roda o `RODAR.bat`; ao terminar, um aviso no canto da tela diz quantas ações novas chegaram.
  `AGENDAR.bat` faz o mesmo à mão (botão direito, Executar como administrador), se precisar. O DJEN termina de publicar o Diário do dia à noite (por volta das 19h); de madrugada, o Diário do dia novo só aparece depois das 3h.
- **`RODAR.bat`**: uma rodada sem a tela, com os tribunais salvos. Também grava `saida\radar\radar.html`.
- **`DIAGNOSTICO.bat`**: relatório `diagnostico\radar-diagnostico.txt` do que o robô guardou, sem dado de pessoa física.

- **`PREPARAR-PARA-CLIENTE.bat`**: depois de testar numa pasta, apaga config, banco e saídas e deixa a pasta pronta para
  copiar para outro computador (o Python já instalado vai junto).

## Atualização assinada

O suporte publica versões novas na subpasta `atualizacao` da pasta compartilhada (o Drive leva até o computador)
ou num endereço fixo. O robô só instala se a assinatura digital do pacote bater com a chave pública que está em
`chave_publica.txt`, ao lado deste arquivo, e se o conteúdo bater com o resumo criptográfico do manifesto. Sem
`chave_publica.txt`, a atualização fica desligada. O `config.json`, o banco, a pasta `python` e a pasta `saida`
nunca são tocados; a versão anterior fica guardada em `_anterior\`.

## O que é automático e o que fica com gente

| Dado | Como chega |
|---|---|
| Ação nova, partes (empresas), vara, rito, data do Diário | automático, pelo Diário (DJEN) |
| CNPJ | automático quando está no texto do Diário; senão, do clique no PJe |
| Porte, capital, CNAE, cidade, telefone, e-mail, sócios | automático, pela Receita, quando há CNPJ |
| Valor da causa e data de distribuição | pessoa, no PJe (captcha), digitado na página |
| Faturamento | não é público; o porte dá a faixa (micro até R$ 360 mil; pequena até R$ 4,8 milhões; demais acima) |

## Cuidados

- Poucos pedidos, com intervalo. Não aumente a velocidade nem rode várias cópias ao mesmo tempo.
- A tela só responde ao navegador deste computador (endereço 127.0.0.1). Nada é publicado na internet.
- O robô não burla captcha nem usa senha ou certificado de ninguém. Pessoas físicas nunca aparecem.
- O "desligar pelo suporte" (aba Controle) é uma chave de cortesia, não uma trava: quem tem o computador pode
  alterar a planilha. Ele serve para pausar, avisar e pedir atualização, não para impedir uso.
